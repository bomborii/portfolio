HospitalAssignment.exe is the executable for this project. It is a simulation of a hospital that treats patients
with various afflictions and records the statistics of those patients. The status of patients is updated every second.

HospitalSimulation.sln is the solution for the program written in C#. This file must be opened with Visual Studio