﻿namespace HospitalAssignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtNumberOfBeds = new System.Windows.Forms.TextBox();
            this.lblConfirmBeds = new System.Windows.Forms.Label();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.tmrFrameRate = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // txtNumberOfBeds
            // 
            this.txtNumberOfBeds.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumberOfBeds.Location = new System.Drawing.Point(27, 216);
            this.txtNumberOfBeds.Name = "txtNumberOfBeds";
            this.txtNumberOfBeds.Size = new System.Drawing.Size(56, 26);
            this.txtNumberOfBeds.TabIndex = 0;
            // 
            // lblConfirmBeds
            // 
            this.lblConfirmBeds.AutoSize = true;
            this.lblConfirmBeds.BackColor = System.Drawing.Color.Transparent;
            this.lblConfirmBeds.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmBeds.ForeColor = System.Drawing.Color.White;
            this.lblConfirmBeds.Location = new System.Drawing.Point(15, 252);
            this.lblConfirmBeds.Name = "lblConfirmBeds";
            this.lblConfirmBeds.Size = new System.Drawing.Size(78, 18);
            this.lblConfirmBeds.TabIndex = 1;
            this.lblConfirmBeds.Text = "CONFIRM";
            this.lblConfirmBeds.Click += new System.EventHandler(this.lblConfirmBeds_Click);
            // 
            // lblInstructions
            // 
            this.lblInstructions.AutoSize = true;
            this.lblInstructions.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructions.ForeColor = System.Drawing.Color.White;
            this.lblInstructions.Location = new System.Drawing.Point(122, 21);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(672, 176);
            this.lblInstructions.TabIndex = 3;
            this.lblInstructions.Text = resources.GetString("lblInstructions.Text");
            // 
            // tmrFrameRate
            // 
            this.tmrFrameRate.Enabled = true;
            this.tmrFrameRate.Interval = 1000;
            this.tmrFrameRate.Tick += new System.EventHandler(this.tmrFrameRate_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(1240, 664);
            this.Controls.Add(this.lblInstructions);
            this.Controls.Add(this.lblConfirmBeds);
            this.Controls.Add(this.txtNumberOfBeds);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(700, 400);
            this.Name = "Form1";
            this.Text = "Hospital Rush";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNumberOfBeds;
        private System.Windows.Forms.Label lblConfirmBeds;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.Timer tmrFrameRate;
    }
}

