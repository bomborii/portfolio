This project was the final group project of a course called Human-Computer Interaction. In this project, we were tasked with 
creating a remote home system for a hypothetical person with physical impairments. We had to brainstorm numerous features for this system,
and every feature needed to have a scanning system equipped. A scanning system is a one-input system that allows the user to interact with 
the system by using only one input, such as a button. Then, due to time constraints, we implemented the Entertainment, Navigation, 
Communications, and Environment Controls features. I was personally responsible for the Entertainment feature, and it properly implements 
the scanning system unlike some of the other implemented features.