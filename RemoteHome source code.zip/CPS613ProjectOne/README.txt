This project was the final group project of a course called Human-Computer Interaction. In this project, we were tasked with 
creating a remote home system 