﻿Public Class ControlLights
    Dim chosenOption = "Entire Apartment"

    Private Sub ButtonOn_Click(sender As Object, e As EventArgs) Handles ButtonOn.Click
        MessageBox.Show("You have turned on the lights for " + chosenOption)
    End Sub

    Private Sub PickedOption_SelectedIndexChanged(sender As Object, e As EventArgs) Handles PickedOption.SelectedIndexChanged
        chosenOption = PickedOption.SelectedItem.ToString()
        lblDescription.Text = "You are currently controlling the lights for " + chosenOption
    End Sub

    Private Sub ButtonIntermediate_Click(sender As Object, e As EventArgs) Handles ButtonIntermediate.Click
        MessageBox.Show("You have picked the intermediate light option for  " + chosenOption)
    End Sub

    Private Sub ButtonOff_Click(sender As Object, e As EventArgs) Handles ButtonOff.Click
        MessageBox.Show("You have turned off the lights for " + chosenOption)
    End Sub
End Class
