﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CallForAssistance
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pboxSherry = New System.Windows.Forms.PictureBox()
        Me.pboxRhea = New System.Windows.Forms.PictureBox()
        Me.btnCallSherry = New System.Windows.Forms.Button()
        Me.btnCallRhea = New System.Windows.Forms.Button()
        Me.lblCallingSherryNotif = New System.Windows.Forms.Label()
        Me.lblCallingRheaNotif = New System.Windows.Forms.Label()
        CType(Me.pboxSherry, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboxRhea, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pboxSherry
        '
        Me.pboxSherry.Image = Global.ProjectOne.My.Resources.Resource1.sherryIcon2
        Me.pboxSherry.InitialImage = Global.ProjectOne.My.Resources.Resource1.assitanceIcon
        Me.pboxSherry.Location = New System.Drawing.Point(87, 94)
        Me.pboxSherry.Name = "pboxSherry"
        Me.pboxSherry.Size = New System.Drawing.Size(182, 175)
        Me.pboxSherry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboxSherry.TabIndex = 0
        Me.pboxSherry.TabStop = False
        '
        'pboxRhea
        '
        Me.pboxRhea.Image = Global.ProjectOne.My.Resources.Resource1.rheaIcon
        Me.pboxRhea.InitialImage = Global.ProjectOne.My.Resources.Resource1.assitanceIcon
        Me.pboxRhea.Location = New System.Drawing.Point(420, 94)
        Me.pboxRhea.Name = "pboxRhea"
        Me.pboxRhea.Size = New System.Drawing.Size(182, 175)
        Me.pboxRhea.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboxRhea.TabIndex = 1
        Me.pboxRhea.TabStop = False
        '
        'btnCallSherry
        '
        Me.btnCallSherry.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnCallSherry.Location = New System.Drawing.Point(87, 272)
        Me.btnCallSherry.Name = "btnCallSherry"
        Me.btnCallSherry.Size = New System.Drawing.Size(182, 59)
        Me.btnCallSherry.TabIndex = 4
        Me.btnCallSherry.Text = "Call Sherry"
        Me.btnCallSherry.UseVisualStyleBackColor = True
        '
        'btnCallRhea
        '
        Me.btnCallRhea.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnCallRhea.Location = New System.Drawing.Point(420, 272)
        Me.btnCallRhea.Name = "btnCallRhea"
        Me.btnCallRhea.Size = New System.Drawing.Size(182, 59)
        Me.btnCallRhea.TabIndex = 5
        Me.btnCallRhea.Text = "Call Rhea"
        Me.btnCallRhea.UseVisualStyleBackColor = True
        '
        'lblCallingSherryNotif
        '
        Me.lblCallingSherryNotif.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblCallingSherryNotif.Location = New System.Drawing.Point(59, 5)
        Me.lblCallingSherryNotif.Name = "lblCallingSherryNotif"
        Me.lblCallingSherryNotif.Size = New System.Drawing.Size(248, 86)
        Me.lblCallingSherryNotif.TabIndex = 6
        Me.lblCallingSherryNotif.Text = "Sherry is being notified that you need assistance"
        Me.lblCallingSherryNotif.Visible = False
        '
        'lblCallingRheaNotif
        '
        Me.lblCallingRheaNotif.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblCallingRheaNotif.Location = New System.Drawing.Point(388, 5)
        Me.lblCallingRheaNotif.Name = "lblCallingRheaNotif"
        Me.lblCallingRheaNotif.Size = New System.Drawing.Size(248, 86)
        Me.lblCallingRheaNotif.TabIndex = 7
        Me.lblCallingRheaNotif.Text = "Rhea is being notified that you need assistance"
        Me.lblCallingRheaNotif.Visible = False
        '
        'CallForAssistance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.lblCallingRheaNotif)
        Me.Controls.Add(Me.lblCallingSherryNotif)
        Me.Controls.Add(Me.btnCallRhea)
        Me.Controls.Add(Me.btnCallSherry)
        Me.Controls.Add(Me.pboxRhea)
        Me.Controls.Add(Me.pboxSherry)
        Me.Name = "CallForAssistance"
        Me.Size = New System.Drawing.Size(691, 455)
        CType(Me.pboxSherry, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboxRhea, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pboxSherry As PictureBox
    Friend WithEvents pboxRhea As PictureBox
    Friend WithEvents btnCallSherry As Button
    Friend WithEvents btnCallRhea As Button
    Friend WithEvents lblCallingSherryNotif As Label
    Friend WithEvents lblCallingRheaNotif As Label
End Class
