﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TemperatureControl
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.IncreaseTemperature = New System.Windows.Forms.Button()
        Me.ReduceTemperature = New System.Windows.Forms.Button()
        Me.lblTemperature = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.TemperatureTimer = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'IncreaseTemperature
        '
        Me.IncreaseTemperature.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.IncreaseTemperature.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.IncreaseTemperature.Location = New System.Drawing.Point(94, 211)
        Me.IncreaseTemperature.Name = "IncreaseTemperature"
        Me.IncreaseTemperature.Size = New System.Drawing.Size(57, 51)
        Me.IncreaseTemperature.TabIndex = 0
        Me.IncreaseTemperature.Text = "+"
        Me.IncreaseTemperature.UseVisualStyleBackColor = True
        '
        'ReduceTemperature
        '
        Me.ReduceTemperature.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ReduceTemperature.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ReduceTemperature.Location = New System.Drawing.Point(262, 211)
        Me.ReduceTemperature.Name = "ReduceTemperature"
        Me.ReduceTemperature.Size = New System.Drawing.Size(57, 51)
        Me.ReduceTemperature.TabIndex = 2
        Me.ReduceTemperature.Text = "-"
        Me.ReduceTemperature.UseVisualStyleBackColor = True
        '
        'lblTemperature
        '
        Me.lblTemperature.AutoSize = True
        Me.lblTemperature.Font = New System.Drawing.Font("Segoe UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblTemperature.Location = New System.Drawing.Point(108, 92)
        Me.lblTemperature.Name = "lblTemperature"
        Me.lblTemperature.Size = New System.Drawing.Size(211, 86)
        Me.lblTemperature.TabIndex = 3
        Me.lblTemperature.Text = "15 ° C"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(143, 20)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(69, 19)
        Me.CheckBox1.TabIndex = 4
        Me.CheckBox1.Text = "Room A"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(143, 45)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(68, 19)
        Me.CheckBox2.TabIndex = 5
        Me.CheckBox2.Text = "Room B"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(143, 70)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(69, 19)
        Me.CheckBox3.TabIndex = 6
        Me.CheckBox3.Text = "Room C"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'TemperatureTimer
        '
        Me.TemperatureTimer.Enabled = True
        Me.TemperatureTimer.Interval = 2000
        '
        'TemperatureControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.CheckBox3)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.lblTemperature)
        Me.Controls.Add(Me.ReduceTemperature)
        Me.Controls.Add(Me.IncreaseTemperature)
        Me.DoubleBuffered = True
        Me.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.Name = "TemperatureControl"
        Me.Size = New System.Drawing.Size(402, 296)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents IncreaseTemperature As Button
    Friend WithEvents ReduceTemperature As Button
    Friend WithEvents lblTemperature As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents TemperatureTimer As Timer
End Class
