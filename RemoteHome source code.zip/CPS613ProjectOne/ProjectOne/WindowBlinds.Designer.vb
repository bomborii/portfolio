﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WindowBlinds
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.WindowChoice = New System.Windows.Forms.ComboBox()
        Me.RoomChoice = New System.Windows.Forms.ComboBox()
        Me.ButtonFullyClosedWithSlats = New System.Windows.Forms.Button()
        Me.ButtonFullyClosed = New System.Windows.Forms.Button()
        Me.ButtonHalfOpen = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.FullyOpen = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblStatus.Location = New System.Drawing.Point(27, 87)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(587, 30)
        Me.lblStatus.TabIndex = 18
        Me.lblStatus.Text = "The Entire Apartment's All Windows blinds will be fully closed."
        '
        'WindowChoice
        '
        Me.WindowChoice.FormattingEnabled = True
        Me.WindowChoice.Items.AddRange(New Object() {"All Windows", "Window A", "Window B", "Window C"})
        Me.WindowChoice.Location = New System.Drawing.Point(385, 38)
        Me.WindowChoice.Name = "WindowChoice"
        Me.WindowChoice.Size = New System.Drawing.Size(121, 23)
        Me.WindowChoice.TabIndex = 17
        '
        'RoomChoice
        '
        Me.RoomChoice.FormattingEnabled = True
        Me.RoomChoice.Items.AddRange(New Object() {"Entire Apartment", "Current Room", "Room A", "Room B", "Room C"})
        Me.RoomChoice.Location = New System.Drawing.Point(68, 39)
        Me.RoomChoice.Name = "RoomChoice"
        Me.RoomChoice.Size = New System.Drawing.Size(121, 23)
        Me.RoomChoice.TabIndex = 16
        '
        'ButtonFullyClosedWithSlats
        '
        Me.ButtonFullyClosedWithSlats.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonFullyClosedWithSlats.Location = New System.Drawing.Point(467, 316)
        Me.ButtonFullyClosedWithSlats.Name = "ButtonFullyClosedWithSlats"
        Me.ButtonFullyClosedWithSlats.Size = New System.Drawing.Size(147, 69)
        Me.ButtonFullyClosedWithSlats.TabIndex = 15
        Me.ButtonFullyClosedWithSlats.Text = "Fully Closed With Slats"
        Me.ButtonFullyClosedWithSlats.UseVisualStyleBackColor = True
        '
        'ButtonFullyClosed
        '
        Me.ButtonFullyClosed.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonFullyClosed.Location = New System.Drawing.Point(306, 325)
        Me.ButtonFullyClosed.Name = "ButtonFullyClosed"
        Me.ButtonFullyClosed.Size = New System.Drawing.Size(155, 51)
        Me.ButtonFullyClosed.TabIndex = 14
        Me.ButtonFullyClosed.Text = "Fully Closed"
        Me.ButtonFullyClosed.UseVisualStyleBackColor = True
        '
        'ButtonHalfOpen
        '
        Me.ButtonHalfOpen.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonHalfOpen.Location = New System.Drawing.Point(168, 325)
        Me.ButtonHalfOpen.Name = "ButtonHalfOpen"
        Me.ButtonHalfOpen.Size = New System.Drawing.Size(128, 51)
        Me.ButtonHalfOpen.TabIndex = 13
        Me.ButtonHalfOpen.Text = "Half Open"
        Me.ButtonHalfOpen.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ProjectOne.My.Resources.Resource1.windowblinds1
        Me.PictureBox1.Location = New System.Drawing.Point(207, 132)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(213, 169)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'FullyOpen
        '
        Me.FullyOpen.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.FullyOpen.Location = New System.Drawing.Point(34, 325)
        Me.FullyOpen.Name = "FullyOpen"
        Me.FullyOpen.Size = New System.Drawing.Size(128, 51)
        Me.FullyOpen.TabIndex = 11
        Me.FullyOpen.Text = "Fully Open"
        Me.FullyOpen.UseVisualStyleBackColor = True
        '
        'WindowBlinds
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.WindowChoice)
        Me.Controls.Add(Me.RoomChoice)
        Me.Controls.Add(Me.ButtonFullyClosedWithSlats)
        Me.Controls.Add(Me.ButtonFullyClosed)
        Me.Controls.Add(Me.ButtonHalfOpen)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.FullyOpen)
        Me.Name = "WindowBlinds"
        Me.Size = New System.Drawing.Size(649, 415)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblStatus As Label
    Friend WithEvents WindowChoice As ComboBox
    Friend WithEvents RoomChoice As ComboBox
    Friend WithEvents ButtonFullyClosedWithSlats As Button
    Friend WithEvents ButtonFullyClosed As Button
    Friend WithEvents ButtonHalfOpen As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents FullyOpen As Button
End Class
