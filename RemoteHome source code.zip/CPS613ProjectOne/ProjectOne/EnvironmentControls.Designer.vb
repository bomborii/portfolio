﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EnvironmentControls
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EnvironmentControls))
        Me.PictureTemperature = New System.Windows.Forms.PictureBox()
        Me.PictureVentilation = New System.Windows.Forms.PictureBox()
        Me.PictureHumidity = New System.Windows.Forms.PictureBox()
        Me.lblTemperature = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureWindows = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PictureBlinds = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureLights = New System.Windows.Forms.PictureBox()
        Me.BackButton = New System.Windows.Forms.Button()
        Me.EnvironmentTimer = New System.Windows.Forms.Timer(Me.components)
        CType(Me.PictureTemperature, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureVentilation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureHumidity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureWindows, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBlinds, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureLights, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureTemperature
        '
        Me.PictureTemperature.Image = Global.ProjectOne.My.Resources.Resource1.ThermostatTwo
        Me.PictureTemperature.Location = New System.Drawing.Point(114, 77)
        Me.PictureTemperature.Name = "PictureTemperature"
        Me.PictureTemperature.Size = New System.Drawing.Size(91, 82)
        Me.PictureTemperature.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureTemperature.TabIndex = 0
        Me.PictureTemperature.TabStop = False
        '
        'PictureVentilation
        '
        Me.PictureVentilation.Image = Global.ProjectOne.My.Resources.Resource1.Ventilation
        Me.PictureVentilation.Location = New System.Drawing.Point(297, 77)
        Me.PictureVentilation.Name = "PictureVentilation"
        Me.PictureVentilation.Size = New System.Drawing.Size(91, 82)
        Me.PictureVentilation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureVentilation.TabIndex = 3
        Me.PictureVentilation.TabStop = False
        '
        'PictureHumidity
        '
        Me.PictureHumidity.Image = Global.ProjectOne.My.Resources.Resource1.Humidity
        Me.PictureHumidity.Location = New System.Drawing.Point(477, 77)
        Me.PictureHumidity.Name = "PictureHumidity"
        Me.PictureHumidity.Size = New System.Drawing.Size(91, 82)
        Me.PictureHumidity.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureHumidity.TabIndex = 4
        Me.PictureHumidity.TabStop = False
        '
        'lblTemperature
        '
        Me.lblTemperature.AutoSize = True
        Me.lblTemperature.Location = New System.Drawing.Point(100, 162)
        Me.lblTemperature.Name = "lblTemperature"
        Me.lblTemperature.Size = New System.Drawing.Size(116, 15)
        Me.lblTemperature.TabIndex = 5
        Me.lblTemperature.Text = "Control Temperature"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(282, 162)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 15)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Control Ventilation"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(468, 162)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 15)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Control Humidity"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(651, 162)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(99, 15)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Control Windows"
        '
        'PictureWindows
        '
        Me.PictureWindows.Image = Global.ProjectOne.My.Resources.Resource1.Window
        Me.PictureWindows.Location = New System.Drawing.Point(660, 77)
        Me.PictureWindows.Name = "PictureWindows"
        Me.PictureWindows.Size = New System.Drawing.Size(91, 82)
        Me.PictureWindows.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureWindows.TabIndex = 8
        Me.PictureWindows.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(105, 330)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 15)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Control Blinds"
        '
        'PictureBlinds
        '
        Me.PictureBlinds.Image = Global.ProjectOne.My.Resources.Resource1.windowblinds
        Me.PictureBlinds.Location = New System.Drawing.Point(114, 245)
        Me.PictureBlinds.Name = "PictureBlinds"
        Me.PictureBlinds.Size = New System.Drawing.Size(91, 82)
        Me.PictureBlinds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBlinds.TabIndex = 10
        Me.PictureBlinds.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(306, 330)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(82, 15)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Control Lights"
        '
        'PictureLights
        '
        Me.PictureLights.Image = CType(resources.GetObject("PictureLights.Image"), System.Drawing.Image)
        Me.PictureLights.Location = New System.Drawing.Point(297, 245)
        Me.PictureLights.Name = "PictureLights"
        Me.PictureLights.Size = New System.Drawing.Size(91, 82)
        Me.PictureLights.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureLights.TabIndex = 12
        Me.PictureLights.TabStop = False
        '
        'BackButton
        '
        Me.BackButton.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.BackButton.Location = New System.Drawing.Point(25, 392)
        Me.BackButton.Name = "BackButton"
        Me.BackButton.Size = New System.Drawing.Size(84, 33)
        Me.BackButton.TabIndex = 16
        Me.BackButton.Text = "Back"
        Me.BackButton.UseVisualStyleBackColor = True
        '
        'EnvironmentTimer
        '
        Me.EnvironmentTimer.Enabled = True
        Me.EnvironmentTimer.Interval = 2000
        '
        'EnvironmentControls
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.BackButton)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureLights)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBlinds)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PictureWindows)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTemperature)
        Me.Controls.Add(Me.PictureHumidity)
        Me.Controls.Add(Me.PictureVentilation)
        Me.Controls.Add(Me.PictureTemperature)
        Me.Name = "EnvironmentControls"
        Me.Text = "EnvironmentControls"
        CType(Me.PictureTemperature, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureVentilation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureHumidity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureWindows, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBlinds, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureLights, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureTemperature As PictureBox
    Friend WithEvents PictureVentilation As PictureBox
    Friend WithEvents PictureHumidity As PictureBox
    Friend WithEvents lblTemperature As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureWindows As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBlinds As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureLights As PictureBox
    Friend WithEvents BackButton As Button
    Friend WithEvents EnvironmentTimer As Timer
End Class
