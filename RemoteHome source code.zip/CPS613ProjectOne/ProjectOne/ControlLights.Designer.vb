﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ControlLights
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ButtonOn = New System.Windows.Forms.Button()
        Me.ButtonIntermediate = New System.Windows.Forms.Button()
        Me.ButtonOff = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PickedOption = New System.Windows.Forms.ComboBox()
        Me.lblDescription = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonOn
        '
        Me.ButtonOn.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonOn.Location = New System.Drawing.Point(110, 342)
        Me.ButtonOn.Name = "ButtonOn"
        Me.ButtonOn.Size = New System.Drawing.Size(111, 53)
        Me.ButtonOn.TabIndex = 0
        Me.ButtonOn.Text = "On"
        Me.ButtonOn.UseVisualStyleBackColor = True
        '
        'ButtonIntermediate
        '
        Me.ButtonIntermediate.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonIntermediate.Location = New System.Drawing.Point(263, 347)
        Me.ButtonIntermediate.Name = "ButtonIntermediate"
        Me.ButtonIntermediate.Size = New System.Drawing.Size(202, 43)
        Me.ButtonIntermediate.TabIndex = 1
        Me.ButtonIntermediate.Text = "Intermediate"
        Me.ButtonIntermediate.UseVisualStyleBackColor = True
        '
        'ButtonOff
        '
        Me.ButtonOff.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonOff.Location = New System.Drawing.Point(500, 342)
        Me.ButtonOff.Name = "ButtonOff"
        Me.ButtonOff.Size = New System.Drawing.Size(108, 53)
        Me.ButtonOff.TabIndex = 2
        Me.ButtonOff.Text = "Off"
        Me.ButtonOff.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ProjectOne.My.Resources.Resource1.lightbulb
        Me.PictureBox1.Location = New System.Drawing.Point(252, 123)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(213, 182)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'PickedOption
        '
        Me.PickedOption.FormattingEnabled = True
        Me.PickedOption.Items.AddRange(New Object() {"Entire Apartment", "Current Room", "Specific Room", "Current Area in Room"})
        Me.PickedOption.Location = New System.Drawing.Point(298, 76)
        Me.PickedOption.Name = "PickedOption"
        Me.PickedOption.Size = New System.Drawing.Size(121, 23)
        Me.PickedOption.TabIndex = 4
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblDescription.Location = New System.Drawing.Point(17, 27)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(688, 32)
        Me.lblDescription.TabIndex = 5
        Me.lblDescription.Text = "You are currently controlling the lights for the entire apartment"
        '
        'ControlLights
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.lblDescription)
        Me.Controls.Add(Me.PickedOption)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ButtonOff)
        Me.Controls.Add(Me.ButtonIntermediate)
        Me.Controls.Add(Me.ButtonOn)
        Me.Name = "ControlLights"
        Me.Size = New System.Drawing.Size(708, 432)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ButtonOn As Button
    Friend WithEvents ButtonIntermediate As Button
    Friend WithEvents ButtonOff As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PickedOption As ComboBox
    Friend WithEvents lblDescription As Label
End Class
