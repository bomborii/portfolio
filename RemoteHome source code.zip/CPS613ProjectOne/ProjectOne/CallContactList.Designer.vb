﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CallContactList
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCallAmara = New System.Windows.Forms.Button()
        Me.btnCallMiranda = New System.Windows.Forms.Button()
        Me.btnCallRay = New System.Windows.Forms.Button()
        Me.btnCallMax = New System.Windows.Forms.Button()
        Me.lblSpeedDial1 = New System.Windows.Forms.Label()
        Me.lblSpeedDial2 = New System.Windows.Forms.Label()
        Me.lblSpeedDial3 = New System.Windows.Forms.Label()
        Me.lblSpeedDial4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCallAmara
        '
        Me.btnCallAmara.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnCallAmara.Location = New System.Drawing.Point(42, 59)
        Me.btnCallAmara.Name = "btnCallAmara"
        Me.btnCallAmara.Size = New System.Drawing.Size(197, 73)
        Me.btnCallAmara.TabIndex = 0
        Me.btnCallAmara.Text = "Call Amara"
        Me.btnCallAmara.UseVisualStyleBackColor = True
        '
        'btnCallMiranda
        '
        Me.btnCallMiranda.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnCallMiranda.Location = New System.Drawing.Point(448, 59)
        Me.btnCallMiranda.Name = "btnCallMiranda"
        Me.btnCallMiranda.Size = New System.Drawing.Size(197, 73)
        Me.btnCallMiranda.TabIndex = 1
        Me.btnCallMiranda.Text = "Call Miranda"
        Me.btnCallMiranda.UseVisualStyleBackColor = True
        '
        'btnCallRay
        '
        Me.btnCallRay.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnCallRay.Location = New System.Drawing.Point(42, 273)
        Me.btnCallRay.Name = "btnCallRay"
        Me.btnCallRay.Size = New System.Drawing.Size(197, 73)
        Me.btnCallRay.TabIndex = 2
        Me.btnCallRay.Text = "Call Ray"
        Me.btnCallRay.UseVisualStyleBackColor = True
        '
        'btnCallMax
        '
        Me.btnCallMax.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnCallMax.Location = New System.Drawing.Point(448, 273)
        Me.btnCallMax.Name = "btnCallMax"
        Me.btnCallMax.Size = New System.Drawing.Size(197, 73)
        Me.btnCallMax.TabIndex = 3
        Me.btnCallMax.Text = "Call Max"
        Me.btnCallMax.UseVisualStyleBackColor = True
        '
        'lblSpeedDial1
        '
        Me.lblSpeedDial1.AutoSize = True
        Me.lblSpeedDial1.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblSpeedDial1.Location = New System.Drawing.Point(52, 16)
        Me.lblSpeedDial1.Name = "lblSpeedDial1"
        Me.lblSpeedDial1.Size = New System.Drawing.Size(177, 40)
        Me.lblSpeedDial1.TabIndex = 4
        Me.lblSpeedDial1.Text = "Speed Dial 1"
        '
        'lblSpeedDial2
        '
        Me.lblSpeedDial2.AutoSize = True
        Me.lblSpeedDial2.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblSpeedDial2.Location = New System.Drawing.Point(457, 16)
        Me.lblSpeedDial2.Name = "lblSpeedDial2"
        Me.lblSpeedDial2.Size = New System.Drawing.Size(177, 40)
        Me.lblSpeedDial2.TabIndex = 5
        Me.lblSpeedDial2.Text = "Speed Dial 2"
        '
        'lblSpeedDial3
        '
        Me.lblSpeedDial3.AutoSize = True
        Me.lblSpeedDial3.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblSpeedDial3.Location = New System.Drawing.Point(52, 230)
        Me.lblSpeedDial3.Name = "lblSpeedDial3"
        Me.lblSpeedDial3.Size = New System.Drawing.Size(177, 40)
        Me.lblSpeedDial3.TabIndex = 6
        Me.lblSpeedDial3.Text = "Speed Dial 3"
        '
        'lblSpeedDial4
        '
        Me.lblSpeedDial4.AutoSize = True
        Me.lblSpeedDial4.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblSpeedDial4.Location = New System.Drawing.Point(457, 230)
        Me.lblSpeedDial4.Name = "lblSpeedDial4"
        Me.lblSpeedDial4.Size = New System.Drawing.Size(177, 40)
        Me.lblSpeedDial4.TabIndex = 7
        Me.lblSpeedDial4.Text = "Speed Dial 4"
        '
        'CallContactList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.lblSpeedDial4)
        Me.Controls.Add(Me.lblSpeedDial3)
        Me.Controls.Add(Me.lblSpeedDial2)
        Me.Controls.Add(Me.lblSpeedDial1)
        Me.Controls.Add(Me.btnCallMax)
        Me.Controls.Add(Me.btnCallRay)
        Me.Controls.Add(Me.btnCallMiranda)
        Me.Controls.Add(Me.btnCallAmara)
        Me.Name = "CallContactList"
        Me.Size = New System.Drawing.Size(691, 455)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCallAmara As Button
    Friend WithEvents btnCallMiranda As Button
    Friend WithEvents btnCallRay As Button
    Friend WithEvents btnCallMax As Button
    Friend WithEvents lblSpeedDial1 As Label
    Friend WithEvents lblSpeedDial2 As Label
    Friend WithEvents lblSpeedDial3 As Label
    Friend WithEvents lblSpeedDial4 As Label
End Class
