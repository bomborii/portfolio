﻿Public Class CommunicationsForm


    Public PreviousCommunicationsControls As CommunicationsControls
    Public Shared Calling As Boolean

    Public Sub New(CommunicationsControlsReference As Object)

        Me.PreviousCommunicationsControls = CommunicationsControlsReference
        ' This call is required by the designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
        MakeInvisible()


    End Sub


    Public Sub MakeInvisible()
        Me.CallForAssistance.Visible = False
        Me.CallForAssistance.Enabled = False
        Me.CallContactList.Visible = False
        Me.CallContactList.Enabled = False
        Me.CallScreen.Visible = False
        Me.CallScreen.Enabled = False
        Me.CallScreenMale1.Visible = False
        Me.CallScreenMale1.Enabled = False

    End Sub

    Public Sub showCorrectScreen(chosenOption)
        If chosenOption = "Call For Assistance" Then
            MakeInvisible()
            Me.CallForAssistance.Visible = True
            Me.CallForAssistance.Enabled = True
        ElseIf chosenOption = "Call Contact List" Then
            MakeInvisible()
            Me.CallContactList.Visible = True
            Me.CallContactList.Enabled = True
        ElseIf chosenOption = "Call Screen" Then
            MakeInvisible()
            Me.btnBack.Enabled = False
            Me.btnBack.Visible = False
            Me.CallScreen.Visible = True
            Me.CallScreen.Enabled = True
        ElseIf chosenOption = "Call Screen Male" Then
            MakeInvisible()
            Me.btnBack.Enabled = False
            Me.btnBack.Visible = False
            Me.CallScreenMale1.Visible = True
            Me.CallScreenMale1.Enabled = True
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        Me.PreviousCommunicationsControls.Show()
    End Sub
End Class