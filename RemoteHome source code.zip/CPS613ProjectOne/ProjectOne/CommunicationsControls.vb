﻿Public Class CommunicationsControls

    Public NewForm As New CommunicationsForm(Me)

    Public Sub New(flag1 As Boolean, flag2 As Boolean)

        ' This call is required by the designer.
        InitializeComponent()
        If flag1 = True Then
            Me.pboxAtTheDoorNotif.Visible = True
        End If
        If flag2 = True Then
            Me.pboxCallNotif.Visible = True
        End If
        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub btnBackCommunicationForm_Click(sender As Object, e As EventArgs) Handles btnBackCommunicationForm.Click

        Me.Close()
    End Sub

    Private Sub pboxCallAssistance_Click(sender As Object, e As EventArgs) Handles pboxCallAssistance.Click
        If NewForm.Visible = False Then
            NewForm.showCorrectScreen("Call For Assistance")
            NewForm.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub pboxPhoneCall_Click(sender As Object, e As EventArgs) Handles pboxPhoneCall.Click
        If NewForm.Visible = False Then
            NewForm.showCorrectScreen("Call Contact List")
            NewForm.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub pboxTexting_Click(sender As Object, e As EventArgs) Handles pboxTexting.Click
        If NewForm.Visible = False Then

        End If
    End Sub

    Private Sub pboxAtTheDoor_Click(sender As Object, e As EventArgs) Handles pboxOpenFrontDoor.Click
        Me.lblOpeningDoorNotif.Visible = True
    End Sub


End Class