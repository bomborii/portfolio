﻿Public Class Form1
    Private callNotifFlag As Boolean = False
    Private atTheDoorNotifFlag As Boolean = False

    Private totalbuttons As Integer
    Private Buttons As Button()
    Private activebutton As Integer

    'When scanner is on the icon
    Private communicationsPicked As Boolean = False
    Private environmentPicked As Boolean = False
    Private washroomPicked As Boolean = True
    Private sleepPicked As Boolean = False
    Private entertainmentPicked As Boolean = False
    Private navigationPicked As Boolean = False
    Private wheelchairPicked As Boolean = False
    Private vaccumPicked As Boolean = False
    Private schedulePicked As Boolean = False

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        Using pen As New Pen(Color.Red)
            If communicationsPicked = True Then
                e.Graphics.DrawRectangle(pen, Communications.Location.X - 10, Communications.Location.Y - 5, Communications.Width + 25, Communications.Height + 25)
            ElseIf environmentPicked = True Then
                e.Graphics.DrawRectangle(pen, Environment.Location.X - 10, Environment.Location.Y - 5, Environment.Width + 25, Environment.Height + 25)
            ElseIf washroomPicked = True Then
                e.Graphics.DrawRectangle(pen, Washroom.Location.X - 10, Washroom.Location.Y - 5, Washroom.Width + 25, Washroom.Height + 25)
            ElseIf sleepPicked = True Then
                e.Graphics.DrawRectangle(pen, Sleep.Location.X - 10, Sleep.Location.Y - 5, Sleep.Width + 25, Sleep.Height + 25)
            ElseIf entertainmentPicked = True Then
                e.Graphics.DrawRectangle(pen, Entertainment.Location.X - 10, Entertainment.Location.Y - 5, Entertainment.Width + 25, Entertainment.Height + 25)
            ElseIf navigationPicked = True Then
                e.Graphics.DrawRectangle(pen, Navigation.Location.X - 10, Navigation.Location.Y - 5, Navigation.Width + 25, Navigation.Height + 25)
            ElseIf wheelchairPicked = True Then
                e.Graphics.DrawRectangle(pen, Movement.Location.X - 10, Movement.Location.Y - 5, Movement.Width + 25, Movement.Height + 25)
            ElseIf vaccumPicked = True Then
                e.Graphics.DrawRectangle(pen, Vaccum.Location.X - 10, Vaccum.Location.Y - 5, Vaccum.Width + 25, Vaccum.Height + 25)
            ElseIf schedulePicked = True Then
                e.Graphics.DrawRectangle(pen, Schedule.Location.X - 10, Schedule.Location.Y - 5, Schedule.Width + 25, Schedule.Height + 25)
            End If
        End Using
        'Add your custom paint code here
    End Sub


    Private Sub Communications_MouseClick(sender As Object, e As MouseEventArgs) Handles Communications.MouseClick

    End Sub

    Private Sub Environment_Click(sender As Object, e As EventArgs) Handles Environment.Click
        Dim NewForm As New EnvironmentControls
        NewForm.Show()
    End Sub

    Private Sub Communications_Click(sender As Object, e As EventArgs) Handles Communications.Click
        Dim NewForm As New CommunicationsControls(atTheDoorNotifFlag, callNotifFlag)
        NewForm.Show()
    End Sub

    Private Sub doorBellMessageTimer_Tick(sender As Object, e As EventArgs) Handles doorBellMessageTimer.Tick
        Me.doorBellMessageTimer.Enabled = False
        atTheDoorNotifFlag = True
        MessageBox.Show("There is someone at the Door")
    End Sub

    Private Sub callNotificationTimer_Tick(sender As Object, e As EventArgs) Handles callNotificationTimer.Tick
        Me.callNotificationTimer.Enabled = False
        callNotifFlag = True
        MessageBox.Show("Dre is calling you!")
    End Sub
    Private Sub Navigation_Click(sender As Object, e As EventArgs) Handles Navigation.Click
        Dim NewForm As New TemperatureForm("Doors")
        NewForm.Text = "Navigation"
        NewForm.Show()
    End Sub

    Private Sub Entertainment_Click(sender As Object, e As EventArgs) Handles Entertainment.Click
        Dim NewForm As New EntertainmentForm
        NewForm.Show()
    End Sub

    Private Sub ScannerTimer_Tick(sender As Object, e As EventArgs) Handles ScannerTimer.Tick
        If washroomPicked = True Then
            washroomPicked = False
            sleepPicked = True
        ElseIf sleepPicked = True Then
            sleepPicked = False
            entertainmentPicked = True
        ElseIf entertainmentPicked = True Then
            entertainmentPicked = False
            navigationPicked = True
        ElseIf navigationPicked = True Then
            navigationPicked = False
            wheelchairPicked = True
        ElseIf wheelchairPicked = True Then
            wheelchairPicked = False
            communicationsPicked = True
        ElseIf communicationsPicked = True Then
            communicationsPicked = False
            environmentPicked = True
        ElseIf environmentPicked = True Then
            environmentPicked = False
            vaccumPicked = True
        ElseIf vaccumPicked = True Then
            vaccumPicked = False
            schedulePicked = True
        ElseIf schedulePicked = True Then
            schedulePicked = False
            washroomPicked = True
        End If
        Refresh()
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Space Then
            If washroomPicked = True Then
                MessageBox.Show("Unfortunately the feature has not been created yet")
            ElseIf sleepPicked = True Then
                MessageBox.Show("Unfortunately the feature has not been created yet")
            ElseIf entertainmentPicked = True Then
                Dim NewForm As New EntertainmentForm
                NewForm.Show()
            ElseIf navigationPicked = True Then
                Dim NewForm As New TemperatureForm("Doors")
                NewForm.Text = "Navigation"
                NewForm.Show()
            ElseIf wheelchairPicked = True Then
                MessageBox.Show("Unfortunately the feature has not been created yet")
            ElseIf communicationsPicked = True Then
                Dim NewForm As New CommunicationsControls(atTheDoorNotifFlag, callNotifFlag)
                NewForm.Show()
            ElseIf environmentPicked = True Then
                Dim NewForm As New EnvironmentControls
                NewForm.Show()
            ElseIf vaccumPicked = True Then
                MessageBox.Show("Unfortunately the feature has not been created yet")
            ElseIf schedulePicked = True Then
                MessageBox.Show("Unfortunately the feature has not been created yet")
            End If
        End If
    End Sub

    Private Sub Washroom_Click(sender As Object, e As EventArgs) Handles Washroom.Click

    End Sub
End Class
