﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EntertainmentForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EntertainmentForm))
        Me.btnTelevision = New System.Windows.Forms.Button()
        Me.btnMusic = New System.Windows.Forms.Button()
        Me.tmrEntertainmentScanner = New System.Windows.Forms.Timer(Me.components)
        Me.picTelevision = New System.Windows.Forms.PictureBox()
        Me.picMusic = New System.Windows.Forms.PictureBox()
        CType(Me.picTelevision, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMusic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnTelevision
        '
        Me.btnTelevision.Enabled = False
        Me.btnTelevision.Location = New System.Drawing.Point(404, 124)
        Me.btnTelevision.Name = "btnTelevision"
        Me.btnTelevision.Size = New System.Drawing.Size(98, 55)
        Me.btnTelevision.TabIndex = 5
        Me.btnTelevision.Text = "Television"
        Me.btnTelevision.UseVisualStyleBackColor = True
        '
        'btnMusic
        '
        Me.btnMusic.Location = New System.Drawing.Point(270, 124)
        Me.btnMusic.Name = "btnMusic"
        Me.btnMusic.Size = New System.Drawing.Size(98, 55)
        Me.btnMusic.TabIndex = 4
        Me.btnMusic.Text = "Music"
        Me.btnMusic.UseVisualStyleBackColor = True
        '
        'tmrEntertainmentScanner
        '
        Me.tmrEntertainmentScanner.Enabled = True
        Me.tmrEntertainmentScanner.Interval = 1000
        '
        'picTelevision
        '
        Me.picTelevision.Image = CType(resources.GetObject("picTelevision.Image"), System.Drawing.Image)
        Me.picTelevision.Location = New System.Drawing.Point(402, 204)
        Me.picTelevision.Name = "picTelevision"
        Me.picTelevision.Size = New System.Drawing.Size(100, 84)
        Me.picTelevision.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picTelevision.TabIndex = 6
        Me.picTelevision.TabStop = False
        '
        'picMusic
        '
        Me.picMusic.Image = CType(resources.GetObject("picMusic.Image"), System.Drawing.Image)
        Me.picMusic.Location = New System.Drawing.Point(270, 204)
        Me.picMusic.Name = "picMusic"
        Me.picMusic.Size = New System.Drawing.Size(98, 84)
        Me.picMusic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMusic.TabIndex = 7
        Me.picMusic.TabStop = False
        '
        'EntertainmentForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.picMusic)
        Me.Controls.Add(Me.picTelevision)
        Me.Controls.Add(Me.btnTelevision)
        Me.Controls.Add(Me.btnMusic)
        Me.Name = "EntertainmentForm"
        Me.Text = "EntertainmentForm"
        CType(Me.picTelevision, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMusic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnTelevision As Button
    Friend WithEvents btnMusic As Button
    Friend WithEvents tmrEntertainmentScanner As Timer
    Friend WithEvents picTelevision As PictureBox
    Friend WithEvents picMusic As PictureBox
End Class
