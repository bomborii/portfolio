﻿Imports System.Drawing.Drawing2D

Public Class TemperatureControl
    Dim temperature = 15

    Private plus As Boolean = False
    Private minus As Boolean = False
    Private roomA As Boolean = True
    Private roomB As Boolean = False
    Private roomC As Boolean = False

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        Using pen As New Pen(Color.Red)
            If roomA = True Then
                e.Graphics.DrawRectangle(pen, CheckBox1.Location.X - 10, CheckBox1.Location.Y - 5, CheckBox1.Width + 25, CheckBox1.Height + 25)
            ElseIf roomB = True Then
                e.Graphics.DrawRectangle(pen, CheckBox2.Location.X - 10, CheckBox2.Location.Y - 5, CheckBox2.Width + 25, CheckBox2.Height + 25)
            ElseIf roomC = True Then
                e.Graphics.DrawRectangle(pen, CheckBox3.Location.X - 10, CheckBox3.Location.Y - 5, CheckBox3.Width + 25, CheckBox3.Height + 25)
            ElseIf plus = True Then
                e.Graphics.DrawRectangle(pen, IncreaseTemperature.Location.X - 10, IncreaseTemperature.Location.Y - 5, IncreaseTemperature.Width + 25, IncreaseTemperature.Height + 25)
            ElseIf minus = True Then
                e.Graphics.DrawRectangle(pen, ReduceTemperature.Location.X - 10, ReduceTemperature.Location.Y - 5, ReduceTemperature.Width + 25, ReduceTemperature.Height + 25)
            End If
        End Using
        'Add your custom paint code here
    End Sub

    Private Sub IncreaseTemperature_Click(sender As Object, e As EventArgs) Handles IncreaseTemperature.Click
        If temperature < 33 Then
            temperature += 1
            lblTemperature.Text = temperature.ToString() + " ° C"
        End If
    End Sub

    Private Sub ReduceTemperature_Click(sender As Object, e As EventArgs) Handles ReduceTemperature.Click
        If temperature > 11 Then
            temperature -= 1
            lblTemperature.Text = temperature.ToString() + " ° C"
        End If
    End Sub

    Private Sub TemperatureTimer_Tick(sender As Object, e As EventArgs) Handles TemperatureTimer.Tick
        If roomA = True Then
            roomA = False
            roomB = True
        ElseIf roomB = True Then
            roomB = False
            roomC = True
        ElseIf roomC = True Then
            roomC = False
            plus = True
        ElseIf plus = True Then
            plus = False
            minus = True
        ElseIf minus = True Then
            minus = False
            roomA = True
        End If
        Refresh()
    End Sub

    Private Sub TemperatureControl_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Space Then
            If roomA = True Then
                If CheckBox1.Checked = True Then
                    CheckBox1.Checked = False
                Else
                    CheckBox1.Checked = True
                End If
            ElseIf roomB = True Then
                If CheckBox2.Checked = True Then
                    CheckBox2.Checked = False
                Else
                    CheckBox2.Checked = True
                End If
            ElseIf roomC = True Then
                If CheckBox2.Checked = True Then
                    CheckBox2.Checked = False
                Else
                    CheckBox2.Checked = True
                End If
            ElseIf plus = True Then
                If temperature < 33 Then
                    temperature += 1
                    lblTemperature.Text = temperature.ToString() + " ° C"
                End If
            ElseIf minus = True Then
                If temperature > 11 Then
                    temperature -= 1
                    lblTemperature.Text = temperature.ToString() + " ° C"
                End If
            End If
        End If
    End Sub
End Class
