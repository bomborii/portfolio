﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CallScreenMale
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMessageDisplay = New System.Windows.Forms.Label()
        Me.lblHangUp = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.pBox = New System.Windows.Forms.PictureBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblMessageDisplay
        '
        Me.lblMessageDisplay.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblMessageDisplay.Location = New System.Drawing.Point(161, 279)
        Me.lblMessageDisplay.Name = "lblMessageDisplay"
        Me.lblMessageDisplay.Size = New System.Drawing.Size(359, 66)
        Me.lblMessageDisplay.TabIndex = 15
        Me.lblMessageDisplay.Text = "HELLO"
        Me.lblMessageDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblMessageDisplay.Visible = False
        '
        'lblHangUp
        '
        Me.lblHangUp.AutoSize = True
        Me.lblHangUp.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblHangUp.Location = New System.Drawing.Point(39, 138)
        Me.lblHangUp.Name = "lblHangUp"
        Me.lblHangUp.Size = New System.Drawing.Size(108, 32)
        Me.lblHangUp.TabIndex = 14
        Me.lblHangUp.Text = "Hang Up"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.ProjectOne.My.Resources.Resource1.EndCallIcon
        Me.PictureBox2.Location = New System.Drawing.Point(39, 28)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(106, 107)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 13
        Me.PictureBox2.TabStop = False
        '
        'pBox
        '
        Me.pBox.Image = Global.ProjectOne.My.Resources.Resource1.MaxAndRayIcon
        Me.pBox.Location = New System.Drawing.Point(209, 12)
        Me.pBox.Name = "pBox"
        Me.pBox.Size = New System.Drawing.Size(264, 266)
        Me.pBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pBox.TabIndex = 8
        Me.pBox.TabStop = False
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button4.Location = New System.Drawing.Point(584, 362)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(93, 68)
        Me.Button4.TabIndex = 19
        Me.Button4.Tag = "PLEASE COME OVER"
        Me.Button4.Text = "Come Over"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button3.Location = New System.Drawing.Point(402, 362)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(93, 68)
        Me.Button3.TabIndex = 18
        Me.Button3.Tag = "NO"
        Me.Button3.Text = "No"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button2.Location = New System.Drawing.Point(209, 362)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(93, 68)
        Me.Button2.TabIndex = 17
        Me.Button2.Tag = "YES"
        Me.Button2.Text = "Yes"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button1.Location = New System.Drawing.Point(22, 362)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(93, 68)
        Me.Button1.TabIndex = 16
        Me.Button1.Tag = "HELLO"
        Me.Button1.Text = "Hello"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CallScreenMale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblMessageDisplay)
        Me.Controls.Add(Me.lblHangUp)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.pBox)
        Me.Name = "CallScreenMale"
        Me.Size = New System.Drawing.Size(699, 455)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMessageDisplay As Label
    Friend WithEvents lblHangUp As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents pBox As PictureBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
