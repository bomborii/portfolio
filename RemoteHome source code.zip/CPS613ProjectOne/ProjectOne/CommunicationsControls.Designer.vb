﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CommunicationsControls
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pboxCallAssistance = New System.Windows.Forms.PictureBox()
        Me.lblCallForAssitance = New System.Windows.Forms.Label()
        Me.lblPhoneCall = New System.Windows.Forms.Label()
        Me.pboxPhoneCall = New System.Windows.Forms.PictureBox()
        Me.lblTexting = New System.Windows.Forms.Label()
        Me.pboxTexting = New System.Windows.Forms.PictureBox()
        Me.lblAtTheDoor = New System.Windows.Forms.Label()
        Me.pboxOpenFrontDoor = New System.Windows.Forms.PictureBox()
        Me.btnBackCommunicationForm = New System.Windows.Forms.Button()
        Me.lblOpeningDoorNotif = New System.Windows.Forms.Label()
        Me.pboxCallNotif = New System.Windows.Forms.PictureBox()
        Me.pboxAtTheDoorNotif = New System.Windows.Forms.PictureBox()
        CType(Me.pboxCallAssistance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboxPhoneCall, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboxTexting, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboxOpenFrontDoor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboxCallNotif, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboxAtTheDoorNotif, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pboxCallAssistance
        '
        Me.pboxCallAssistance.Image = Global.ProjectOne.My.Resources.Resource1.assitanceIcon
        Me.pboxCallAssistance.Location = New System.Drawing.Point(69, 42)
        Me.pboxCallAssistance.Name = "pboxCallAssistance"
        Me.pboxCallAssistance.Size = New System.Drawing.Size(90, 82)
        Me.pboxCallAssistance.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboxCallAssistance.TabIndex = 0
        Me.pboxCallAssistance.TabStop = False
        '
        'lblCallForAssitance
        '
        Me.lblCallForAssitance.AutoSize = True
        Me.lblCallForAssitance.Location = New System.Drawing.Point(63, 127)
        Me.lblCallForAssitance.Name = "lblCallForAssitance"
        Me.lblCallForAssitance.Size = New System.Drawing.Size(105, 15)
        Me.lblCallForAssitance.TabIndex = 10
        Me.lblCallForAssitance.Text = "Call For Assistance"
        Me.lblCallForAssitance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPhoneCall
        '
        Me.lblPhoneCall.AutoSize = True
        Me.lblPhoneCall.Location = New System.Drawing.Point(233, 127)
        Me.lblPhoneCall.Name = "lblPhoneCall"
        Me.lblPhoneCall.Size = New System.Drawing.Size(69, 15)
        Me.lblPhoneCall.TabIndex = 12
        Me.lblPhoneCall.Text = "Phone Calls"
        Me.lblPhoneCall.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pboxPhoneCall
        '
        Me.pboxPhoneCall.Image = Global.ProjectOne.My.Resources.Resource1.callperson
        Me.pboxPhoneCall.Location = New System.Drawing.Point(222, 42)
        Me.pboxPhoneCall.Name = "pboxPhoneCall"
        Me.pboxPhoneCall.Size = New System.Drawing.Size(90, 82)
        Me.pboxPhoneCall.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboxPhoneCall.TabIndex = 11
        Me.pboxPhoneCall.TabStop = False
        '
        'lblTexting
        '
        Me.lblTexting.AutoSize = True
        Me.lblTexting.Location = New System.Drawing.Point(398, 127)
        Me.lblTexting.Name = "lblTexting"
        Me.lblTexting.Size = New System.Drawing.Size(45, 15)
        Me.lblTexting.TabIndex = 14
        Me.lblTexting.Text = "Texting"
        Me.lblTexting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pboxTexting
        '
        Me.pboxTexting.Image = Global.ProjectOne.My.Resources.Resource1.TextMessage1
        Me.pboxTexting.Location = New System.Drawing.Point(376, 42)
        Me.pboxTexting.Name = "pboxTexting"
        Me.pboxTexting.Size = New System.Drawing.Size(90, 82)
        Me.pboxTexting.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboxTexting.TabIndex = 13
        Me.pboxTexting.TabStop = False
        '
        'lblAtTheDoor
        '
        Me.lblAtTheDoor.AutoSize = True
        Me.lblAtTheDoor.Location = New System.Drawing.Point(526, 127)
        Me.lblAtTheDoor.Name = "lblAtTheDoor"
        Me.lblAtTheDoor.Size = New System.Drawing.Size(96, 15)
        Me.lblAtTheDoor.TabIndex = 16
        Me.lblAtTheDoor.Text = "Open Front Door"
        Me.lblAtTheDoor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pboxOpenFrontDoor
        '
        Me.pboxOpenFrontDoor.Image = Global.ProjectOne.My.Resources.Resource1.door
        Me.pboxOpenFrontDoor.Location = New System.Drawing.Point(529, 42)
        Me.pboxOpenFrontDoor.Name = "pboxOpenFrontDoor"
        Me.pboxOpenFrontDoor.Size = New System.Drawing.Size(90, 82)
        Me.pboxOpenFrontDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboxOpenFrontDoor.TabIndex = 15
        Me.pboxOpenFrontDoor.TabStop = False
        '
        'btnBackCommunicationForm
        '
        Me.btnBackCommunicationForm.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnBackCommunicationForm.Location = New System.Drawing.Point(25, 392)
        Me.btnBackCommunicationForm.Name = "btnBackCommunicationForm"
        Me.btnBackCommunicationForm.Size = New System.Drawing.Size(84, 33)
        Me.btnBackCommunicationForm.TabIndex = 17
        Me.btnBackCommunicationForm.Text = "Back"
        Me.btnBackCommunicationForm.UseVisualStyleBackColor = True
        '
        'lblOpeningDoorNotif
        '
        Me.lblOpeningDoorNotif.AutoSize = True
        Me.lblOpeningDoorNotif.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblOpeningDoorNotif.Location = New System.Drawing.Point(376, 199)
        Me.lblOpeningDoorNotif.Name = "lblOpeningDoorNotif"
        Me.lblOpeningDoorNotif.Size = New System.Drawing.Size(377, 32)
        Me.lblOpeningDoorNotif.TabIndex = 18
        Me.lblOpeningDoorNotif.Text = "Your front door is now opening"
        Me.lblOpeningDoorNotif.Visible = False
        '
        'pboxCallNotif
        '
        Me.pboxCallNotif.Image = Global.ProjectOne.My.Resources.Resource1.notifIcon
        Me.pboxCallNotif.Location = New System.Drawing.Point(290, 12)
        Me.pboxCallNotif.Name = "pboxCallNotif"
        Me.pboxCallNotif.Size = New System.Drawing.Size(49, 72)
        Me.pboxCallNotif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboxCallNotif.TabIndex = 19
        Me.pboxCallNotif.TabStop = False
        Me.pboxCallNotif.Visible = False
        '
        'pboxAtTheDoorNotif
        '
        Me.pboxAtTheDoorNotif.Image = Global.ProjectOne.My.Resources.Resource1.notifIcon
        Me.pboxAtTheDoorNotif.Location = New System.Drawing.Point(595, 12)
        Me.pboxAtTheDoorNotif.Name = "pboxAtTheDoorNotif"
        Me.pboxAtTheDoorNotif.Size = New System.Drawing.Size(49, 72)
        Me.pboxAtTheDoorNotif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pboxAtTheDoorNotif.TabIndex = 20
        Me.pboxAtTheDoorNotif.TabStop = False
        Me.pboxAtTheDoorNotif.Visible = False
        '
        'CommunicationsControls
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.pboxAtTheDoorNotif)
        Me.Controls.Add(Me.pboxCallNotif)
        Me.Controls.Add(Me.lblOpeningDoorNotif)
        Me.Controls.Add(Me.btnBackCommunicationForm)
        Me.Controls.Add(Me.lblAtTheDoor)
        Me.Controls.Add(Me.pboxOpenFrontDoor)
        Me.Controls.Add(Me.lblTexting)
        Me.Controls.Add(Me.pboxTexting)
        Me.Controls.Add(Me.lblPhoneCall)
        Me.Controls.Add(Me.pboxPhoneCall)
        Me.Controls.Add(Me.lblCallForAssitance)
        Me.Controls.Add(Me.pboxCallAssistance)
        Me.Name = "CommunicationsControls"
        Me.Text = "Communications Controls"
        CType(Me.pboxCallAssistance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboxPhoneCall, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboxTexting, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboxOpenFrontDoor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboxCallNotif, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboxAtTheDoorNotif, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pboxCallAssistance As PictureBox
    Friend WithEvents lblCallForAssitance As Label
    Friend WithEvents lblPhoneCall As Label
    Friend WithEvents pboxPhoneCall As PictureBox
    Friend WithEvents lblTexting As Label
    Friend WithEvents pboxTexting As PictureBox
    Friend WithEvents lblAtTheDoor As Label
    Friend WithEvents pboxOpenFrontDoor As PictureBox
    Friend WithEvents btnBackCommunicationForm As Button
    Friend WithEvents lblOpeningDoorNotif As Label
    Friend WithEvents pboxCallNotif As PictureBox
    Friend WithEvents pboxAtTheDoorNotif As PictureBox
End Class
