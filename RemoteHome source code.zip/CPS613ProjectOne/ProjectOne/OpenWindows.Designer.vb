﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class OpenWindows
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.FullyOpen = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ButtonHalfOpen = New System.Windows.Forms.Button()
        Me.ButtonSlightlyOpen = New System.Windows.Forms.Button()
        Me.ButtonFullyClosed = New System.Windows.Forms.Button()
        Me.RoomChoice = New System.Windows.Forms.ComboBox()
        Me.WindowChoice = New System.Windows.Forms.ComboBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FullyOpen
        '
        Me.FullyOpen.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.FullyOpen.Location = New System.Drawing.Point(8, 308)
        Me.FullyOpen.Name = "FullyOpen"
        Me.FullyOpen.Size = New System.Drawing.Size(128, 51)
        Me.FullyOpen.TabIndex = 0
        Me.FullyOpen.Text = "Fully Open"
        Me.FullyOpen.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ProjectOne.My.Resources.Resource1.Window1
        Me.PictureBox1.Location = New System.Drawing.Point(181, 115)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(213, 169)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'ButtonHalfOpen
        '
        Me.ButtonHalfOpen.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonHalfOpen.Location = New System.Drawing.Point(142, 308)
        Me.ButtonHalfOpen.Name = "ButtonHalfOpen"
        Me.ButtonHalfOpen.Size = New System.Drawing.Size(128, 51)
        Me.ButtonHalfOpen.TabIndex = 5
        Me.ButtonHalfOpen.Text = "Half Open"
        Me.ButtonHalfOpen.UseVisualStyleBackColor = True
        '
        'ButtonSlightlyOpen
        '
        Me.ButtonSlightlyOpen.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonSlightlyOpen.Location = New System.Drawing.Point(280, 308)
        Me.ButtonSlightlyOpen.Name = "ButtonSlightlyOpen"
        Me.ButtonSlightlyOpen.Size = New System.Drawing.Size(155, 51)
        Me.ButtonSlightlyOpen.TabIndex = 6
        Me.ButtonSlightlyOpen.Text = "Slightly Open"
        Me.ButtonSlightlyOpen.UseVisualStyleBackColor = True
        '
        'ButtonFullyClosed
        '
        Me.ButtonFullyClosed.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonFullyClosed.Location = New System.Drawing.Point(441, 308)
        Me.ButtonFullyClosed.Name = "ButtonFullyClosed"
        Me.ButtonFullyClosed.Size = New System.Drawing.Size(147, 51)
        Me.ButtonFullyClosed.TabIndex = 7
        Me.ButtonFullyClosed.Text = "Fully Closed"
        Me.ButtonFullyClosed.UseVisualStyleBackColor = True
        '
        'RoomChoice
        '
        Me.RoomChoice.FormattingEnabled = True
        Me.RoomChoice.Items.AddRange(New Object() {"Entire Apartment", "Current Room", "Room A", "Room B", "Room C"})
        Me.RoomChoice.Location = New System.Drawing.Point(42, 22)
        Me.RoomChoice.Name = "RoomChoice"
        Me.RoomChoice.Size = New System.Drawing.Size(121, 23)
        Me.RoomChoice.TabIndex = 8
        '
        'WindowChoice
        '
        Me.WindowChoice.FormattingEnabled = True
        Me.WindowChoice.Items.AddRange(New Object() {"All Windows", "Window A", "Window B", "Window C"})
        Me.WindowChoice.Location = New System.Drawing.Point(359, 21)
        Me.WindowChoice.Name = "WindowChoice"
        Me.WindowChoice.Size = New System.Drawing.Size(121, 23)
        Me.WindowChoice.TabIndex = 9
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblStatus.Location = New System.Drawing.Point(42, 69)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(526, 30)
        Me.lblStatus.TabIndex = 10
        Me.lblStatus.Text = "The Entire Apartment's All Windows will be fully closed."
        '
        'OpenWindows
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.WindowChoice)
        Me.Controls.Add(Me.RoomChoice)
        Me.Controls.Add(Me.ButtonFullyClosed)
        Me.Controls.Add(Me.ButtonSlightlyOpen)
        Me.Controls.Add(Me.ButtonHalfOpen)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.FullyOpen)
        Me.Name = "OpenWindows"
        Me.Size = New System.Drawing.Size(599, 373)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FullyOpen As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ButtonHalfOpen As Button
    Friend WithEvents ButtonSlightlyOpen As Button
    Friend WithEvents ButtonFullyClosed As Button
    Friend WithEvents RoomChoice As ComboBox
    Friend WithEvents WindowChoice As ComboBox
    Friend WithEvents lblStatus As Label
End Class
