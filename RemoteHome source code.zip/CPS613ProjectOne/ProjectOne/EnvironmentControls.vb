﻿Public Class EnvironmentControls
    Private temperature As Boolean = True
    Private ventilation As Boolean = False
    Private humidity As Boolean = False
    Private windows As Boolean = False
    Private blinds As Boolean = False
    Private lights As Boolean = False
    Private back As Boolean = False
    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        Using pen As New Pen(Color.Red)
            If temperature = True Then
                e.Graphics.DrawRectangle(pen, PictureTemperature.Location.X - 10, PictureTemperature.Location.Y - 5, PictureTemperature.Width + 25, PictureTemperature.Height + 25)
            ElseIf ventilation = True Then
                e.Graphics.DrawRectangle(pen, PictureVentilation.Location.X - 10, PictureVentilation.Location.Y - 5, PictureVentilation.Width + 25, PictureVentilation.Height + 25)
            ElseIf humidity = True Then
                e.Graphics.DrawRectangle(pen, PictureHumidity.Location.X - 10, PictureHumidity.Location.Y - 5, PictureHumidity.Width + 25, PictureHumidity.Height + 25)
            ElseIf windows = True Then
                e.Graphics.DrawRectangle(pen, PictureWindows.Location.X - 10, PictureWindows.Location.Y - 5, PictureWindows.Width + 25, PictureWindows.Height + 25)
            ElseIf blinds = True Then
                e.Graphics.DrawRectangle(pen, PictureBlinds.Location.X - 10, PictureBlinds.Location.Y - 5, PictureBlinds.Width + 25, PictureBlinds.Height + 25)
            ElseIf lights = True Then
                e.Graphics.DrawRectangle(pen, PictureLights.Location.X - 10, PictureLights.Location.Y - 5, PictureLights.Width + 25, PictureLights.Height + 25)
            ElseIf back = True Then
                e.Graphics.DrawRectangle(pen, BackButton.Location.X - 10, BackButton.Location.Y - 5, BackButton.Width + 25, BackButton.Height + 25)
            End If
        End Using
        'Add your custom paint code here
    End Sub
    Private Sub PictureTemperature_MouseClick(sender As Object, e As MouseEventArgs) Handles PictureTemperature.MouseClick
        ImagesFalse()
    End Sub

    Public Sub ImagesFalse()
        PictureTemperature.Visible = False
        PictureBlinds.Visible = False
        PictureHumidity.Visible = False
        'PictureRoom.Visible = False
        PictureVentilation.Visible = False
        PictureWindows.Visible = False
        PictureLights.Visible = False
    End Sub

    Private Sub EnvironmentControls_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BackButton.Enabled = False
    End Sub

    Private Sub PictureTemperature_Click(sender As Object, e As EventArgs) Handles PictureTemperature.Click
        Dim NewForm As New TemperatureForm("Temperature")
        NewForm.Show()
        Me.Close()
    End Sub

    Private Sub PictureLights_Click(sender As Object, e As EventArgs) Handles PictureLights.Click
        Dim NewForm As New TemperatureForm("Lights")
        NewForm.Show()
        Me.Close()
    End Sub

    Private Sub PictureBlinds_Click(sender As Object, e As EventArgs) Handles PictureBlinds.Click
        Dim NewForm As New TemperatureForm("Blinds")
        NewForm.Show()
        Me.Close()
    End Sub

    Private Sub BackButton_Click(sender As Object, e As EventArgs) Handles BackButton.Click
        Me.Close()
    End Sub

    Private Sub PictureWindows_Click(sender As Object, e As EventArgs) Handles PictureWindows.Click
        Dim NewForm As New TemperatureForm("Windows")
        NewForm.Show()
        Me.Close()
    End Sub

    'Private Sub PictureRoom_Click(sender As Object, e As EventArgs) Handles PictureRoom.Click
    '    Dim NewForm As New TemperatureForm("Doors")
    '    NewForm.Show()
    '    Me.Close()
    'End Sub

    Private Sub PictureVentilation_Click(sender As Object, e As EventArgs) Handles PictureVentilation.Click
        Dim NewForm As New TemperatureForm("Fans")
        NewForm.Show()
        Me.Close()
    End Sub

    Private Sub PictureHumidity_Click(sender As Object, e As EventArgs) Handles PictureHumidity.Click
        Dim NewForm As New TemperatureForm("Humidity")
        NewForm.Show()
        Me.Close()
    End Sub

    Private Sub EnvironmentTimer_Tick(sender As Object, e As EventArgs) Handles EnvironmentTimer.Tick
        If temperature = True Then
            BackButton.Enabled = False
            temperature = False
            ventilation = True
        ElseIf ventilation = True Then
            ventilation = False
            humidity = True
        ElseIf humidity = True Then
            humidity = False
            windows = True
        ElseIf windows = True Then
            windows = False
            blinds = True
        ElseIf blinds = True Then
            blinds = False
            lights = True
        ElseIf lights = True Then
            lights = False
            back = True
            BackButton.Enabled = True
        ElseIf back = True Then
            back = False
            temperature = True
        End If
        Refresh()
    End Sub

    Private Sub EnvironmentControls_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Space Then
            If temperature = True Then
                Dim NewForm As New TemperatureForm("Temperature")
                NewForm.Show()
                Me.Close()
            ElseIf ventilation = True Then
                Dim NewForm As New TemperatureForm("Fans")
                NewForm.Show()
                Me.Close()
            ElseIf humidity = True Then
                Dim NewForm As New TemperatureForm("Humidity")
                NewForm.Show()
                Me.Close()
            ElseIf windows = True Then
                Dim NewForm As New TemperatureForm("Windows")
                NewForm.Show()
                Me.Close()
            ElseIf blinds = True Then
                Dim NewForm As New TemperatureForm("Blinds")
                NewForm.Show()
                Me.Close()
            ElseIf lights = True Then
                Dim NewForm As New TemperatureForm("Lights")
                NewForm.Show()
                Me.Close()
            ElseIf back = True Then
                Me.Close()
            End If
        End If
    End Sub
End Class