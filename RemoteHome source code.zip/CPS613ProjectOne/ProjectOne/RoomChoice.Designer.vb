﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class RoomChoice
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ButtonUnlock = New System.Windows.Forms.Button()
        Me.ButtonLock = New System.Windows.Forms.Button()
        Me.ButtonClose = New System.Windows.Forms.Button()
        Me.ButtonOpen = New System.Windows.Forms.Button()
        Me.PickedRoom = New System.Windows.Forms.ComboBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblTitle.Location = New System.Drawing.Point(165, 54)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(310, 32)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Control Doors in Apartment"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ProjectOne.My.Resources.Resource1.door
        Me.PictureBox1.Location = New System.Drawing.Point(245, 120)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(165, 156)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'ButtonUnlock
        '
        Me.ButtonUnlock.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonUnlock.Location = New System.Drawing.Point(515, 376)
        Me.ButtonUnlock.Name = "ButtonUnlock"
        Me.ButtonUnlock.Size = New System.Drawing.Size(114, 53)
        Me.ButtonUnlock.TabIndex = 10
        Me.ButtonUnlock.Text = "Unlock"
        Me.ButtonUnlock.UseVisualStyleBackColor = True
        '
        'ButtonLock
        '
        Me.ButtonLock.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonLock.Location = New System.Drawing.Point(369, 376)
        Me.ButtonLock.Name = "ButtonLock"
        Me.ButtonLock.Size = New System.Drawing.Size(108, 53)
        Me.ButtonLock.TabIndex = 9
        Me.ButtonLock.Text = "Lock"
        Me.ButtonLock.UseVisualStyleBackColor = True
        '
        'ButtonClose
        '
        Me.ButtonClose.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonClose.Location = New System.Drawing.Point(189, 378)
        Me.ButtonClose.Name = "ButtonClose"
        Me.ButtonClose.Size = New System.Drawing.Size(145, 48)
        Me.ButtonClose.TabIndex = 8
        Me.ButtonClose.Text = "Close"
        Me.ButtonClose.UseVisualStyleBackColor = True
        '
        'ButtonOpen
        '
        Me.ButtonOpen.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonOpen.Location = New System.Drawing.Point(39, 376)
        Me.ButtonOpen.Name = "ButtonOpen"
        Me.ButtonOpen.Size = New System.Drawing.Size(111, 53)
        Me.ButtonOpen.TabIndex = 7
        Me.ButtonOpen.Text = "Open"
        Me.ButtonOpen.UseVisualStyleBackColor = True
        '
        'PickedRoom
        '
        Me.PickedRoom.FormattingEnabled = True
        Me.PickedRoom.Items.AddRange(New Object() {"Room A Door", "Room B Door", "Room C Door", "Washroom Door", "Apartment Door", "Friend's Apartment"})
        Me.PickedRoom.Location = New System.Drawing.Point(65, 197)
        Me.PickedRoom.Name = "PickedRoom"
        Me.PickedRoom.Size = New System.Drawing.Size(121, 23)
        Me.PickedRoom.TabIndex = 11
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblStatus.Location = New System.Drawing.Point(97, 309)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(453, 32)
        Me.lblStatus.TabIndex = 12
        Me.lblStatus.Text = "Currently Picked: open and Room A Door"
        '
        'RoomChoice
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.PickedRoom)
        Me.Controls.Add(Me.ButtonUnlock)
        Me.Controls.Add(Me.ButtonLock)
        Me.Controls.Add(Me.ButtonClose)
        Me.Controls.Add(Me.ButtonOpen)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "RoomChoice"
        Me.Size = New System.Drawing.Size(643, 485)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ButtonUnlock As Button
    Friend WithEvents ButtonLock As Button
    Friend WithEvents ButtonClose As Button
    Friend WithEvents ButtonOpen As Button
    Friend WithEvents PickedRoom As ComboBox
    Friend WithEvents lblStatus As Label
End Class
