﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TelevisionForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.picNetflix = New System.Windows.Forms.PictureBox()
        Me.picShow1 = New System.Windows.Forms.PictureBox()
        Me.picShow2 = New System.Windows.Forms.PictureBox()
        Me.lblPlaying1 = New System.Windows.Forms.Label()
        Me.lblPlaying2 = New System.Windows.Forms.Label()
        Me.PicTVVolDown = New System.Windows.Forms.PictureBox()
        Me.picTVVolUp = New System.Windows.Forms.PictureBox()
        Me.lblTVVolPrompt = New System.Windows.Forms.Label()
        Me.lblTVVolume = New System.Windows.Forms.Label()
        Me.btnTVFastForward = New System.Windows.Forms.Button()
        Me.btnTVRewind = New System.Windows.Forms.Button()
        Me.btnTVOff = New System.Windows.Forms.Button()
        Me.lblNetflix = New System.Windows.Forms.Label()
        Me.btnPause = New System.Windows.Forms.Button()
        Me.btnPlay = New System.Windows.Forms.Button()
        Me.picPause = New System.Windows.Forms.PictureBox()
        Me.btnVolumeControl = New System.Windows.Forms.Button()
        Me.tmrTelevisionScanner = New System.Windows.Forms.Timer(Me.components)
        Me.btnExitVolumeControlMode = New System.Windows.Forms.Button()
        Me.picPlay = New System.Windows.Forms.PictureBox()
        Me.picRewind = New System.Windows.Forms.PictureBox()
        Me.picFastForward = New System.Windows.Forms.PictureBox()
        CType(Me.picNetflix, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picShow1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picShow2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicTVVolDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTVVolUp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPause, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPlay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRewind, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFastForward, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picNetflix
        '
        Me.picNetflix.Image = Global.ProjectOne.My.Resources.Resource1.download
        Me.picNetflix.Location = New System.Drawing.Point(39, 306)
        Me.picNetflix.Name = "picNetflix"
        Me.picNetflix.Size = New System.Drawing.Size(104, 97)
        Me.picNetflix.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picNetflix.TabIndex = 13
        Me.picNetflix.TabStop = False
        '
        'picShow1
        '
        Me.picShow1.Image = Global.ProjectOne.My.Resources.Resource1.breaking_bad
        Me.picShow1.Location = New System.Drawing.Point(336, 306)
        Me.picShow1.Name = "picShow1"
        Me.picShow1.Size = New System.Drawing.Size(79, 115)
        Me.picShow1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picShow1.TabIndex = 3
        Me.picShow1.TabStop = False
        Me.picShow1.Visible = False
        '
        'picShow2
        '
        Me.picShow2.Image = Global.ProjectOne.My.Resources.Resource1.revenge_of_the_sith
        Me.picShow2.Location = New System.Drawing.Point(487, 306)
        Me.picShow2.Name = "picShow2"
        Me.picShow2.Size = New System.Drawing.Size(80, 115)
        Me.picShow2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picShow2.TabIndex = 4
        Me.picShow2.TabStop = False
        Me.picShow2.Visible = False
        '
        'lblPlaying1
        '
        Me.lblPlaying1.AutoSize = True
        Me.lblPlaying1.Location = New System.Drawing.Point(336, 274)
        Me.lblPlaying1.Name = "lblPlaying1"
        Me.lblPlaying1.Size = New System.Drawing.Size(74, 15)
        Me.lblPlaying1.TabIndex = 5
        Me.lblPlaying1.Text = "Now Playing"
        Me.lblPlaying1.Visible = False
        '
        'lblPlaying2
        '
        Me.lblPlaying2.AutoSize = True
        Me.lblPlaying2.Location = New System.Drawing.Point(487, 274)
        Me.lblPlaying2.Name = "lblPlaying2"
        Me.lblPlaying2.Size = New System.Drawing.Size(74, 15)
        Me.lblPlaying2.TabIndex = 6
        Me.lblPlaying2.Text = "Now Playing"
        Me.lblPlaying2.Visible = False
        '
        'PicTVVolDown
        '
        Me.PicTVVolDown.Image = Global.ProjectOne.My.Resources.Resource1.minus1
        Me.PicTVVolDown.Location = New System.Drawing.Point(113, 42)
        Me.PicTVVolDown.Name = "PicTVVolDown"
        Me.PicTVVolDown.Size = New System.Drawing.Size(68, 65)
        Me.PicTVVolDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicTVVolDown.TabIndex = 7
        Me.PicTVVolDown.TabStop = False
        '
        'picTVVolUp
        '
        Me.picTVVolUp.Image = Global.ProjectOne.My.Resources.Resource1.plus1
        Me.picTVVolUp.Location = New System.Drawing.Point(25, 42)
        Me.picTVVolUp.Name = "picTVVolUp"
        Me.picTVVolUp.Size = New System.Drawing.Size(65, 65)
        Me.picTVVolUp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picTVVolUp.TabIndex = 8
        Me.picTVVolUp.TabStop = False
        '
        'lblTVVolPrompt
        '
        Me.lblTVVolPrompt.AutoSize = True
        Me.lblTVVolPrompt.Location = New System.Drawing.Point(25, 9)
        Me.lblTVVolPrompt.Name = "lblTVVolPrompt"
        Me.lblTVVolPrompt.Size = New System.Drawing.Size(50, 15)
        Me.lblTVVolPrompt.TabIndex = 9
        Me.lblTVVolPrompt.Text = "Volume:"
        '
        'lblTVVolume
        '
        Me.lblTVVolume.AutoSize = True
        Me.lblTVVolume.Location = New System.Drawing.Point(81, 9)
        Me.lblTVVolume.Name = "lblTVVolume"
        Me.lblTVVolume.Size = New System.Drawing.Size(0, 15)
        Me.lblTVVolume.TabIndex = 10
        '
        'btnTVFastForward
        '
        Me.btnTVFastForward.Enabled = False
        Me.btnTVFastForward.Location = New System.Drawing.Point(350, 124)
        Me.btnTVFastForward.Name = "btnTVFastForward"
        Me.btnTVFastForward.Size = New System.Drawing.Size(85, 23)
        Me.btnTVFastForward.TabIndex = 11
        Me.btnTVFastForward.Text = "Fast Forward"
        Me.btnTVFastForward.UseVisualStyleBackColor = True
        '
        'btnTVRewind
        '
        Me.btnTVRewind.Enabled = False
        Me.btnTVRewind.Location = New System.Drawing.Point(239, 124)
        Me.btnTVRewind.Name = "btnTVRewind"
        Me.btnTVRewind.Size = New System.Drawing.Size(75, 23)
        Me.btnTVRewind.TabIndex = 12
        Me.btnTVRewind.Text = "Rewind"
        Me.btnTVRewind.UseVisualStyleBackColor = True
        '
        'btnTVOff
        '
        Me.btnTVOff.Location = New System.Drawing.Point(239, 12)
        Me.btnTVOff.Name = "btnTVOff"
        Me.btnTVOff.Size = New System.Drawing.Size(196, 23)
        Me.btnTVOff.TabIndex = 15
        Me.btnTVOff.Text = "Turn Off Television"
        Me.btnTVOff.UseVisualStyleBackColor = True
        '
        'lblNetflix
        '
        Me.lblNetflix.AutoSize = True
        Me.lblNetflix.Location = New System.Drawing.Point(39, 270)
        Me.lblNetflix.Name = "lblNetflix"
        Me.lblNetflix.Size = New System.Drawing.Size(42, 15)
        Me.lblNetflix.TabIndex = 7
        Me.lblNetflix.Text = "Netflix"
        '
        'btnPause
        '
        Me.btnPause.Enabled = False
        Me.btnPause.Location = New System.Drawing.Point(239, 68)
        Me.btnPause.Name = "btnPause"
        Me.btnPause.Size = New System.Drawing.Size(75, 23)
        Me.btnPause.TabIndex = 16
        Me.btnPause.Text = "Pause"
        Me.btnPause.UseVisualStyleBackColor = True
        '
        'btnPlay
        '
        Me.btnPlay.Enabled = False
        Me.btnPlay.Location = New System.Drawing.Point(350, 68)
        Me.btnPlay.Name = "btnPlay"
        Me.btnPlay.Size = New System.Drawing.Size(85, 23)
        Me.btnPlay.TabIndex = 17
        Me.btnPlay.Text = "Play"
        Me.btnPlay.UseVisualStyleBackColor = True
        '
        'picPause
        '
        Me.picPause.Image = Global.ProjectOne.My.Resources.Resource1.pause
        Me.picPause.Location = New System.Drawing.Point(467, 93)
        Me.picPause.Name = "picPause"
        Me.picPause.Size = New System.Drawing.Size(94, 79)
        Me.picPause.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPause.TabIndex = 18
        Me.picPause.TabStop = False
        Me.picPause.Visible = False
        '
        'btnVolumeControl
        '
        Me.btnVolumeControl.Enabled = False
        Me.btnVolumeControl.Location = New System.Drawing.Point(25, 124)
        Me.btnVolumeControl.Name = "btnVolumeControl"
        Me.btnVolumeControl.Size = New System.Drawing.Size(156, 23)
        Me.btnVolumeControl.TabIndex = 19
        Me.btnVolumeControl.Text = "Volume Control"
        Me.btnVolumeControl.UseVisualStyleBackColor = True
        '
        'tmrTelevisionScanner
        '
        Me.tmrTelevisionScanner.Enabled = True
        Me.tmrTelevisionScanner.Interval = 1000
        '
        'btnExitVolumeControlMode
        '
        Me.btnExitVolumeControlMode.Enabled = False
        Me.btnExitVolumeControlMode.Location = New System.Drawing.Point(25, 164)
        Me.btnExitVolumeControlMode.Name = "btnExitVolumeControlMode"
        Me.btnExitVolumeControlMode.Size = New System.Drawing.Size(156, 23)
        Me.btnExitVolumeControlMode.TabIndex = 20
        Me.btnExitVolumeControlMode.Text = "Exit Volume Control"
        Me.btnExitVolumeControlMode.UseVisualStyleBackColor = True
        '
        'picPlay
        '
        Me.picPlay.Image = Global.ProjectOne.My.Resources.Resource1.play
        Me.picPlay.Location = New System.Drawing.Point(470, 93)
        Me.picPlay.Name = "picPlay"
        Me.picPlay.Size = New System.Drawing.Size(97, 79)
        Me.picPlay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPlay.TabIndex = 21
        Me.picPlay.TabStop = False
        Me.picPlay.Visible = False
        '
        'picRewind
        '
        Me.picRewind.Image = Global.ProjectOne.My.Resources.Resource1.rewind
        Me.picRewind.Location = New System.Drawing.Point(473, 93)
        Me.picRewind.Name = "picRewind"
        Me.picRewind.Size = New System.Drawing.Size(94, 80)
        Me.picRewind.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picRewind.TabIndex = 22
        Me.picRewind.TabStop = False
        Me.picRewind.Visible = False
        '
        'picFastForward
        '
        Me.picFastForward.Image = Global.ProjectOne.My.Resources.Resource1.fast_forward
        Me.picFastForward.Location = New System.Drawing.Point(470, 93)
        Me.picFastForward.Name = "picFastForward"
        Me.picFastForward.Size = New System.Drawing.Size(97, 80)
        Me.picFastForward.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFastForward.TabIndex = 23
        Me.picFastForward.TabStop = False
        Me.picFastForward.Visible = False
        '
        'TelevisionForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.picFastForward)
        Me.Controls.Add(Me.picRewind)
        Me.Controls.Add(Me.picPlay)
        Me.Controls.Add(Me.btnExitVolumeControlMode)
        Me.Controls.Add(Me.btnVolumeControl)
        Me.Controls.Add(Me.picPause)
        Me.Controls.Add(Me.btnPlay)
        Me.Controls.Add(Me.btnPause)
        Me.Controls.Add(Me.lblPlaying2)
        Me.Controls.Add(Me.btnTVFastForward)
        Me.Controls.Add(Me.lblPlaying1)
        Me.Controls.Add(Me.lblNetflix)
        Me.Controls.Add(Me.picShow2)
        Me.Controls.Add(Me.picShow1)
        Me.Controls.Add(Me.btnTVRewind)
        Me.Controls.Add(Me.btnTVOff)
        Me.Controls.Add(Me.picNetflix)
        Me.Controls.Add(Me.picTVVolUp)
        Me.Controls.Add(Me.PicTVVolDown)
        Me.Controls.Add(Me.lblTVVolPrompt)
        Me.Controls.Add(Me.lblTVVolume)
        Me.Name = "TelevisionForm"
        Me.Text = "Television"
        CType(Me.picNetflix, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picShow1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picShow2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicTVVolDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTVVolUp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPause, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPlay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRewind, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFastForward, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picNetflix As PictureBox
    Friend WithEvents picShow1 As PictureBox
    Friend WithEvents picShow2 As PictureBox
    Friend WithEvents lblPlaying1 As Label
    Friend WithEvents lblPlaying2 As Label
    Friend WithEvents PicTVVolDown As PictureBox
    Friend WithEvents picTVVolUp As PictureBox
    Friend WithEvents lblTVVolPrompt As Label
    Friend WithEvents lblTVVolume As Label
    Friend WithEvents btnTVFastForward As Button
    Friend WithEvents btnTVRewind As Button
    Friend WithEvents btnTVOff As Button
    Friend WithEvents lblNetflix As Label
    Friend WithEvents btnPause As Button
    Friend WithEvents btnPlay As Button
    Friend WithEvents picPause As PictureBox
    Friend WithEvents btnVolumeControl As Button
    Friend WithEvents tmrTelevisionScanner As Timer
    Friend WithEvents btnExitVolumeControlMode As Button
    Friend WithEvents picPlay As PictureBox
    Friend WithEvents picRewind As PictureBox
    Friend WithEvents picFastForward As PictureBox
End Class
