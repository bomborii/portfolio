﻿Imports System.Windows.Forms.AxHost

Public Class WindowBlinds


    Private fullOpen As Boolean = True
    Private halfOpen As Boolean = False
    Private fullyClosed As Boolean = False
    Private fullyClosedWithSlats As Boolean = False

    Dim chosenOption = "Entire Apartment"
    Dim chosenOptionTwo = "All Windows"
    Dim state = "will be fully closed"


    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        Using pen As New Pen(Color.Red)
            If fullOpen = True Then
                e.Graphics.DrawRectangle(pen, FullyOpen.Location.X - 10, FullyOpen.Location.Y - 5, FullyOpen.Width + 25, FullyOpen.Height + 25)
            ElseIf halfOpen = True Then
                e.Graphics.DrawRectangle(pen, ButtonHalfOpen.Location.X - 10, ButtonHalfOpen.Location.Y - 5, ButtonHalfOpen.Width + 25, ButtonHalfOpen.Height + 25)
            ElseIf fullyClosed = True Then
                e.Graphics.DrawRectangle(pen, ButtonFullyClosed.Location.X - 10, ButtonFullyClosed.Location.Y - 5, ButtonFullyClosed.Width + 25, ButtonFullyClosed.Height + 25)
            ElseIf fullyClosedWithSlats = True Then
                e.Graphics.DrawRectangle(pen, ButtonFullyClosedWithSlats.Location.X - 10, ButtonFullyClosedWithSlats.Location.Y - 5, ButtonFullyClosedWithSlats.Width + 25, ButtonFullyClosedWithSlats.Height + 25)
            End If
        End Using
        'Add your custom paint code here
    End Sub
    Private Sub WindowChoice_SelectedIndexChanged(sender As Object, e As EventArgs) Handles WindowChoice.SelectedIndexChanged
        chosenOptionTwo = WindowChoice.SelectedItem.ToString()
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state
    End Sub

    Private Sub RoomChoice_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RoomChoice.SelectedIndexChanged
        chosenOption = RoomChoice.SelectedItem.ToString()
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state
    End Sub

    Private Sub FullyOpen_Click(sender As Object, e As EventArgs) Handles FullyOpen.Click
        state = " will be fully open."
        MessageBox.Show("The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state)
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state
    End Sub

    Private Sub ButtonHalfOpen_Click(sender As Object, e As EventArgs) Handles ButtonHalfOpen.Click
        state = " will be half open."
        MessageBox.Show("The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state)
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state
    End Sub

    Private Sub ButtonFullyClosed_Click(sender As Object, e As EventArgs) Handles ButtonFullyClosed.Click
        state = " will be fully closed."
        MessageBox.Show("The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state)
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state
    End Sub

    Private Sub ButtonFullyClosedWithSlats_Click(sender As Object, e As EventArgs) Handles ButtonFullyClosedWithSlats.Click
        state = " will be fully closed with slats."
        MessageBox.Show("The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state)
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " blinds " + state
    End Sub
End Class
