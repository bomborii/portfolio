﻿Public Class CallForAssistance


    Private Sub btnCallSherry_Click(sender As Object, e As EventArgs) Handles btnCallSherry.Click
        lblCallingSherryNotif.Visible = True
    End Sub

    Private Sub btnCallRhea_Click(sender As Object, e As EventArgs) Handles btnCallRhea.Click
        lblCallingRheaNotif.Visible = True
    End Sub
End Class
