﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Washroom = New System.Windows.Forms.PictureBox()
        Me.Sleep = New System.Windows.Forms.PictureBox()
        Me.Entertainment = New System.Windows.Forms.PictureBox()
        Me.Environment = New System.Windows.Forms.PictureBox()
        Me.Communications = New System.Windows.Forms.PictureBox()
        Me.Movement = New System.Windows.Forms.PictureBox()
        Me.Navigation = New System.Windows.Forms.PictureBox()
        Me.Vaccum = New System.Windows.Forms.PictureBox()
        Me.Schedule = New System.Windows.Forms.PictureBox()
        Me.lblWashroom = New System.Windows.Forms.Label()
        Me.lblSleep = New System.Windows.Forms.Label()
        Me.lblEntertainment = New System.Windows.Forms.Label()
        Me.lblNavigation = New System.Windows.Forms.Label()
        Me.lblWheelchair = New System.Windows.Forms.Label()
        Me.lblCommunications = New System.Windows.Forms.Label()
        Me.lblEnvironmentControls = New System.Windows.Forms.Label()
        Me.lblVaccum = New System.Windows.Forms.Label()
        Me.lblSchedule = New System.Windows.Forms.Label()
        Me.doorBellMessageTimer = New System.Windows.Forms.Timer(Me.components)
        Me.callNotificationTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ScannerTimer = New System.Windows.Forms.Timer(Me.components)
        Me.lblInstructions = New System.Windows.Forms.Label()
        CType(Me.Washroom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Sleep, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Entertainment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Environment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Communications, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Movement, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Navigation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Vaccum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Schedule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Washroom
        '
        Me.Washroom.Image = CType(resources.GetObject("Washroom.Image"), System.Drawing.Image)
        Me.Washroom.Location = New System.Drawing.Point(101, 65)
        Me.Washroom.Name = "Washroom"
        Me.Washroom.Size = New System.Drawing.Size(90, 82)
        Me.Washroom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Washroom.TabIndex = 0
        Me.Washroom.TabStop = False
        '
        'Sleep
        '
        Me.Sleep.Image = CType(resources.GetObject("Sleep.Image"), System.Drawing.Image)
        Me.Sleep.Location = New System.Drawing.Point(288, 65)
        Me.Sleep.Name = "Sleep"
        Me.Sleep.Size = New System.Drawing.Size(90, 82)
        Me.Sleep.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Sleep.TabIndex = 1
        Me.Sleep.TabStop = False
        '
        'Entertainment
        '
        Me.Entertainment.Image = CType(resources.GetObject("Entertainment.Image"), System.Drawing.Image)
        Me.Entertainment.Location = New System.Drawing.Point(474, 69)
        Me.Entertainment.Name = "Entertainment"
        Me.Entertainment.Size = New System.Drawing.Size(88, 78)
        Me.Entertainment.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Entertainment.TabIndex = 2
        Me.Entertainment.TabStop = False
        '
        'Environment
        '
        Me.Environment.Image = CType(resources.GetObject("Environment.Image"), System.Drawing.Image)
        Me.Environment.Location = New System.Drawing.Point(474, 212)
        Me.Environment.Name = "Environment"
        Me.Environment.Size = New System.Drawing.Size(88, 78)
        Me.Environment.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Environment.TabIndex = 3
        Me.Environment.TabStop = False
        '
        'Communications
        '
        Me.Communications.Image = CType(resources.GetObject("Communications.Image"), System.Drawing.Image)
        Me.Communications.Location = New System.Drawing.Point(288, 212)
        Me.Communications.Name = "Communications"
        Me.Communications.Size = New System.Drawing.Size(88, 78)
        Me.Communications.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Communications.TabIndex = 4
        Me.Communications.TabStop = False
        '
        'Movement
        '
        Me.Movement.Image = CType(resources.GetObject("Movement.Image"), System.Drawing.Image)
        Me.Movement.Location = New System.Drawing.Point(101, 212)
        Me.Movement.Name = "Movement"
        Me.Movement.Size = New System.Drawing.Size(88, 78)
        Me.Movement.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Movement.TabIndex = 5
        Me.Movement.TabStop = False
        '
        'Navigation
        '
        Me.Navigation.Image = CType(resources.GetObject("Navigation.Image"), System.Drawing.Image)
        Me.Navigation.Location = New System.Drawing.Point(655, 69)
        Me.Navigation.Name = "Navigation"
        Me.Navigation.Size = New System.Drawing.Size(88, 78)
        Me.Navigation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Navigation.TabIndex = 6
        Me.Navigation.TabStop = False
        '
        'Vaccum
        '
        Me.Vaccum.Image = Global.ProjectOne.My.Resources.Resource1.RoboVaccum
        Me.Vaccum.Location = New System.Drawing.Point(655, 212)
        Me.Vaccum.Name = "Vaccum"
        Me.Vaccum.Size = New System.Drawing.Size(88, 78)
        Me.Vaccum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Vaccum.TabIndex = 7
        Me.Vaccum.TabStop = False
        '
        'Schedule
        '
        Me.Schedule.Image = Global.ProjectOne.My.Resources.Resource1.Schedule
        Me.Schedule.Location = New System.Drawing.Point(101, 335)
        Me.Schedule.Name = "Schedule"
        Me.Schedule.Size = New System.Drawing.Size(88, 76)
        Me.Schedule.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Schedule.TabIndex = 8
        Me.Schedule.TabStop = False
        '
        'lblWashroom
        '
        Me.lblWashroom.AutoSize = True
        Me.lblWashroom.Location = New System.Drawing.Point(112, 150)
        Me.lblWashroom.Name = "lblWashroom"
        Me.lblWashroom.Size = New System.Drawing.Size(65, 15)
        Me.lblWashroom.TabIndex = 9
        Me.lblWashroom.Text = "Washroom"
        '
        'lblSleep
        '
        Me.lblSleep.AutoSize = True
        Me.lblSleep.Location = New System.Drawing.Point(316, 150)
        Me.lblSleep.Name = "lblSleep"
        Me.lblSleep.Size = New System.Drawing.Size(35, 15)
        Me.lblSleep.TabIndex = 10
        Me.lblSleep.Text = "Sleep"
        '
        'lblEntertainment
        '
        Me.lblEntertainment.AutoSize = True
        Me.lblEntertainment.Location = New System.Drawing.Point(474, 150)
        Me.lblEntertainment.Name = "lblEntertainment"
        Me.lblEntertainment.Size = New System.Drawing.Size(82, 15)
        Me.lblEntertainment.TabIndex = 11
        Me.lblEntertainment.Text = "Entertainment"
        '
        'lblNavigation
        '
        Me.lblNavigation.AutoSize = True
        Me.lblNavigation.Location = New System.Drawing.Point(667, 150)
        Me.lblNavigation.Name = "lblNavigation"
        Me.lblNavigation.Size = New System.Drawing.Size(65, 15)
        Me.lblNavigation.TabIndex = 12
        Me.lblNavigation.Text = "Navigation"
        '
        'lblWheelchair
        '
        Me.lblWheelchair.AutoSize = True
        Me.lblWheelchair.Location = New System.Drawing.Point(112, 293)
        Me.lblWheelchair.Name = "lblWheelchair"
        Me.lblWheelchair.Size = New System.Drawing.Size(66, 15)
        Me.lblWheelchair.TabIndex = 13
        Me.lblWheelchair.Text = "Wheelchair"
        '
        'lblCommunications
        '
        Me.lblCommunications.AutoSize = True
        Me.lblCommunications.Location = New System.Drawing.Point(279, 293)
        Me.lblCommunications.Name = "lblCommunications"
        Me.lblCommunications.Size = New System.Drawing.Size(99, 15)
        Me.lblCommunications.TabIndex = 14
        Me.lblCommunications.Text = "Communications"
        '
        'lblEnvironmentControls
        '
        Me.lblEnvironmentControls.AutoSize = True
        Me.lblEnvironmentControls.Location = New System.Drawing.Point(455, 293)
        Me.lblEnvironmentControls.Name = "lblEnvironmentControls"
        Me.lblEnvironmentControls.Size = New System.Drawing.Size(123, 15)
        Me.lblEnvironmentControls.TabIndex = 15
        Me.lblEnvironmentControls.Text = "Environment Controls"
        '
        'lblVaccum
        '
        Me.lblVaccum.AutoSize = True
        Me.lblVaccum.Location = New System.Drawing.Point(667, 293)
        Me.lblVaccum.Name = "lblVaccum"
        Me.lblVaccum.Size = New System.Drawing.Size(49, 15)
        Me.lblVaccum.TabIndex = 16
        Me.lblVaccum.Text = "Vaccum"
        '
        'lblSchedule
        '
        Me.lblSchedule.AutoSize = True
        Me.lblSchedule.Location = New System.Drawing.Point(112, 414)
        Me.lblSchedule.Name = "lblSchedule"
        Me.lblSchedule.Size = New System.Drawing.Size(55, 15)
        Me.lblSchedule.TabIndex = 17
        Me.lblSchedule.Text = "Schedule"
        '
        'doorBellMessageTimer
        '
        Me.doorBellMessageTimer.Enabled = True
        Me.doorBellMessageTimer.Interval = 5000
        '
        'callNotificationTimer
        '
        Me.callNotificationTimer.Enabled = True
        Me.callNotificationTimer.Interval = 5000
        '
        'ScannerTimer
        '
        Me.ScannerTimer.Enabled = True
        Me.ScannerTimer.Interval = 2000
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblInstructions.Location = New System.Drawing.Point(62, 19)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(698, 32)
        Me.lblInstructions.TabIndex = 18
        Me.lblInstructions.Text = "Press Space when the red square hovers over the app you want!"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 458)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.lblSchedule)
        Me.Controls.Add(Me.lblVaccum)
        Me.Controls.Add(Me.lblEnvironmentControls)
        Me.Controls.Add(Me.lblCommunications)
        Me.Controls.Add(Me.lblWheelchair)
        Me.Controls.Add(Me.lblNavigation)
        Me.Controls.Add(Me.lblEntertainment)
        Me.Controls.Add(Me.lblSleep)
        Me.Controls.Add(Me.lblWashroom)
        Me.Controls.Add(Me.Schedule)
        Me.Controls.Add(Me.Vaccum)
        Me.Controls.Add(Me.Navigation)
        Me.Controls.Add(Me.Movement)
        Me.Controls.Add(Me.Communications)
        Me.Controls.Add(Me.Environment)
        Me.Controls.Add(Me.Entertainment)
        Me.Controls.Add(Me.Sleep)
        Me.Controls.Add(Me.Washroom)
        Me.Name = "Form1"
        Me.Text = "Project One"
        CType(Me.Washroom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Sleep, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Entertainment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Environment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Communications, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Movement, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Navigation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Vaccum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Schedule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Washroom As PictureBox
    Friend WithEvents Sleep As PictureBox
    Friend WithEvents Entertainment As PictureBox
    Friend WithEvents Environment As PictureBox
    Friend WithEvents Communications As PictureBox
    Friend WithEvents Movement As PictureBox
    Friend WithEvents Navigation As PictureBox
    Friend WithEvents Vaccum As PictureBox
    Friend WithEvents Schedule As PictureBox
    Friend WithEvents lblWashroom As Label
    Friend WithEvents lblSleep As Label
    Friend WithEvents lblEntertainment As Label
    Friend WithEvents lblNavigation As Label
    Friend WithEvents lblWheelchair As Label
    Friend WithEvents lblCommunications As Label
    Friend WithEvents lblEnvironmentControls As Label
    Friend WithEvents lblVaccum As Label
    Friend WithEvents lblSchedule As Label
    Friend WithEvents doorBellMessageTimer As Timer
    Friend WithEvents callNotificationTimer As Timer
    Friend WithEvents ScannerTimer As Timer
    Friend WithEvents lblInstructions As Label
End Class
