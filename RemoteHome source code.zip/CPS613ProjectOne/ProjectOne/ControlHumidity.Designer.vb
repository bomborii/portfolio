﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ControlHumidity
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.lblHumidity = New System.Windows.Forms.Label()
        Me.DecreaseHumidity = New System.Windows.Forms.Button()
        Me.IncreaseHumidity = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(117, 82)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(69, 19)
        Me.CheckBox3.TabIndex = 12
        Me.CheckBox3.Text = "Room C"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(117, 57)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(68, 19)
        Me.CheckBox2.TabIndex = 11
        Me.CheckBox2.Text = "Room B"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(117, 32)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(69, 19)
        Me.CheckBox1.TabIndex = 10
        Me.CheckBox1.Text = "Room A"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'lblHumidity
        '
        Me.lblHumidity.AutoSize = True
        Me.lblHumidity.Font = New System.Drawing.Font("Segoe UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblHumidity.Location = New System.Drawing.Point(82, 104)
        Me.lblHumidity.Name = "lblHumidity"
        Me.lblHumidity.Size = New System.Drawing.Size(167, 86)
        Me.lblHumidity.TabIndex = 9
        Me.lblHumidity.Text = "40%"
        '
        'DecreaseHumidity
        '
        Me.DecreaseHumidity.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.DecreaseHumidity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DecreaseHumidity.Location = New System.Drawing.Point(236, 223)
        Me.DecreaseHumidity.Name = "DecreaseHumidity"
        Me.DecreaseHumidity.Size = New System.Drawing.Size(57, 51)
        Me.DecreaseHumidity.TabIndex = 8
        Me.DecreaseHumidity.Text = "-"
        Me.DecreaseHumidity.UseVisualStyleBackColor = True
        '
        'IncreaseHumidity
        '
        Me.IncreaseHumidity.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.IncreaseHumidity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.IncreaseHumidity.Location = New System.Drawing.Point(68, 223)
        Me.IncreaseHumidity.Name = "IncreaseHumidity"
        Me.IncreaseHumidity.Size = New System.Drawing.Size(57, 51)
        Me.IncreaseHumidity.TabIndex = 7
        Me.IncreaseHumidity.Text = "+"
        Me.IncreaseHumidity.UseVisualStyleBackColor = True
        '
        'ControlHumidity
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.CheckBox3)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.lblHumidity)
        Me.Controls.Add(Me.DecreaseHumidity)
        Me.Controls.Add(Me.IncreaseHumidity)
        Me.Name = "ControlHumidity"
        Me.Size = New System.Drawing.Size(354, 305)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents lblHumidity As Label
    Friend WithEvents DecreaseHumidity As Button
    Friend WithEvents IncreaseHumidity As Button
End Class
