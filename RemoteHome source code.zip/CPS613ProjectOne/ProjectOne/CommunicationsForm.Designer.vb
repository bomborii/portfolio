﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CommunicationsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.CallForAssistance = New ProjectOne.CallForAssistance()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.CallContactList = New ProjectOne.CallContactList()
        Me.CallScreen = New ProjectOne.CallScreen()
        Me.CallScreenMale1 = New ProjectOne.CallScreenMale()
        Me.SuspendLayout()
        '
        'CallForAssistance
        '
        Me.CallForAssistance.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.CallForAssistance.Location = New System.Drawing.Point(53, 12)
        Me.CallForAssistance.Name = "CallForAssistance"
        Me.CallForAssistance.Size = New System.Drawing.Size(690, 410)
        Me.CallForAssistance.TabIndex = 0
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnBack.Location = New System.Drawing.Point(54, 374)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(106, 48)
        Me.btnBack.TabIndex = 18
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'CallContactList
        '
        Me.CallContactList.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.CallContactList.Location = New System.Drawing.Point(53, 12)
        Me.CallContactList.Name = "CallContactList"
        Me.CallContactList.Size = New System.Drawing.Size(691, 410)
        Me.CallContactList.TabIndex = 19
        '
        'CallScreen
        '
        Me.CallScreen.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.CallScreen.Location = New System.Drawing.Point(54, -3)
        Me.CallScreen.Name = "CallScreen"
        Me.CallScreen.Size = New System.Drawing.Size(699, 441)
        Me.CallScreen.TabIndex = 20
        '
        'CallScreenMale1
        '
        Me.CallScreenMale1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.CallScreenMale1.Location = New System.Drawing.Point(53, -3)
        Me.CallScreenMale1.Name = "CallScreenMale1"
        Me.CallScreenMale1.Size = New System.Drawing.Size(699, 455)
        Me.CallScreenMale1.TabIndex = 21
        '
        'CommunicationsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.CallForAssistance)
        Me.Controls.Add(Me.CallContactList)
        Me.Controls.Add(Me.CallScreen)
        Me.Controls.Add(Me.CallScreenMale1)
        Me.Name = "CommunicationsForm"
        Me.Text = "CommunicationsForm"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents CallForAssistance As CallForAssistance
    Friend WithEvents btnBack As Button
    Friend WithEvents CallContactList As CallContactList
    Friend WithEvents CallScreen As CallScreen
    Friend WithEvents CallScreenMale1 As CallScreenMale
End Class
