﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ControlFan
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ButtonLow = New System.Windows.Forms.Button()
        Me.ButtonMedium = New System.Windows.Forms.Button()
        Me.ButtonHigh = New System.Windows.Forms.Button()
        Me.ButtonNoFan = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.RoomOptions = New System.Windows.Forms.ComboBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonLow
        '
        Me.ButtonLow.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonLow.Location = New System.Drawing.Point(410, 329)
        Me.ButtonLow.Name = "ButtonLow"
        Me.ButtonLow.Size = New System.Drawing.Size(108, 53)
        Me.ButtonLow.TabIndex = 5
        Me.ButtonLow.Text = "Low"
        Me.ButtonLow.UseVisualStyleBackColor = True
        '
        'ButtonMedium
        '
        Me.ButtonMedium.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonMedium.Location = New System.Drawing.Point(230, 331)
        Me.ButtonMedium.Name = "ButtonMedium"
        Me.ButtonMedium.Size = New System.Drawing.Size(145, 48)
        Me.ButtonMedium.TabIndex = 4
        Me.ButtonMedium.Text = "Medium"
        Me.ButtonMedium.UseVisualStyleBackColor = True
        '
        'ButtonHigh
        '
        Me.ButtonHigh.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonHigh.Location = New System.Drawing.Point(80, 329)
        Me.ButtonHigh.Name = "ButtonHigh"
        Me.ButtonHigh.Size = New System.Drawing.Size(111, 53)
        Me.ButtonHigh.TabIndex = 3
        Me.ButtonHigh.Text = "High"
        Me.ButtonHigh.UseVisualStyleBackColor = True
        '
        'ButtonNoFan
        '
        Me.ButtonNoFan.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonNoFan.Location = New System.Drawing.Point(556, 329)
        Me.ButtonNoFan.Name = "ButtonNoFan"
        Me.ButtonNoFan.Size = New System.Drawing.Size(114, 53)
        Me.ButtonNoFan.TabIndex = 6
        Me.ButtonNoFan.Text = "No Fan"
        Me.ButtonNoFan.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ProjectOne.My.Resources.Resource1.Ventilation1
        Me.PictureBox1.Location = New System.Drawing.Point(286, 115)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(201, 189)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblDescription.Location = New System.Drawing.Point(80, 57)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(617, 37)
        Me.lblDescription.TabIndex = 8
        Me.lblDescription.Text = "Currently Picked: No Fan and Entire Apartment"
        '
        'RoomOptions
        '
        Me.RoomOptions.FormattingEnabled = True
        Me.RoomOptions.Items.AddRange(New Object() {"Entire Apartment", "Current Room", "Specific Room"})
        Me.RoomOptions.Location = New System.Drawing.Point(80, 194)
        Me.RoomOptions.Name = "RoomOptions"
        Me.RoomOptions.Size = New System.Drawing.Size(121, 23)
        Me.RoomOptions.TabIndex = 9
        '
        'ControlFan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Controls.Add(Me.RoomOptions)
        Me.Controls.Add(Me.lblDescription)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ButtonNoFan)
        Me.Controls.Add(Me.ButtonLow)
        Me.Controls.Add(Me.ButtonMedium)
        Me.Controls.Add(Me.ButtonHigh)
        Me.Name = "ControlFan"
        Me.Size = New System.Drawing.Size(747, 444)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ButtonLow As Button
    Friend WithEvents ButtonMedium As Button
    Friend WithEvents ButtonHigh As Button
    Friend WithEvents ButtonNoFan As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblDescription As Label
    Friend WithEvents RoomOptions As ComboBox
End Class
