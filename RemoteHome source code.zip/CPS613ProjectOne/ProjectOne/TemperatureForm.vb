﻿Public Class TemperatureForm
    Public Sub New(chosenOption)

        ' This call is required by the designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
        MakeInvisible()
        If chosenOption = "Windows" Then
            OpenWindows.Visible = True
            OpenWindows.Enabled = True
        ElseIf chosenOption = "Blinds" Then
            WindowBlinds.Visible = True
            WindowBlinds.Enabled = True
        ElseIf chosenOption = "Temperature" Then
            TemperatureControl.Visible = True
            TemperatureControl.Enabled = True
        ElseIf chosenOption = "Doors" Then
            RoomChoice.Visible = True
            RoomChoice.Enabled = True
        ElseIf chosenOption = "Fans" Then
            ControlFan.Visible = True
            ControlFan.Enabled = True
        ElseIf chosenOption = "Lights" Then
            ControlLights.Visible = True
            ControlLights.Enabled = True
        ElseIf chosenOption = "Humidity" Then
            ControlHumidity.Visible = True
            ControlHumidity.Enabled = True
        End If

    End Sub


    Private Sub TemperatureForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load



    End Sub

    Private Sub BackButton_Click(sender As Object, e As EventArgs) Handles BackButton.Click
        If RoomChoice.Visible = True Then
            Me.Close()
        Else
            Dim NewEnvironmentForm As New EnvironmentControls
            NewEnvironmentForm.Show()
            Me.Close()
        End If
    End Sub

    Public Sub MakeInvisible()
        OpenWindows.Visible = False
        ControlLights.Visible = False
        ControlFan.Visible = False
        WindowBlinds.Visible = False
        RoomChoice.Visible = False
        TemperatureControl.Visible = False
        OpenWindows.Enabled = False
        ControlLights.Enabled = False
        ControlFan.Enabled = False
        WindowBlinds.Enabled = False
        RoomChoice.Enabled = False
        TemperatureControl.Enabled = False
        ControlHumidity.Visible = False
        ControlHumidity.Enabled = False
    End Sub

    Private Sub RoomChoice_Load(sender As Object, e As EventArgs) Handles RoomChoice.Load

    End Sub
End Class