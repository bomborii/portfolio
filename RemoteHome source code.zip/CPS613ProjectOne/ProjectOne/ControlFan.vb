﻿Public Class ControlFan
    Dim chosenOption = "Entire Apartment"
    Dim chosenOptionTwo = "No Fan"

    Private Sub RoomOptions_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RoomOptions.SelectedIndexChanged
        chosenOption = RoomOptions.SelectedItem.ToString()
        lblDescription.Text = "Currently Picked: " + chosenOption + " and " + chosenOptionTwo
    End Sub

    Private Sub ButtonHigh_Click(sender As Object, e As EventArgs) Handles ButtonHigh.Click
        chosenOptionTwo = "High"
        MessageBox.Show("You have turned on the fan for " + chosenOption + " at high setting")
        lblDescription.Text = "Currently Picked: " + chosenOption + " and " + chosenOptionTwo
    End Sub

    Private Sub ButtonMedium_Click(sender As Object, e As EventArgs) Handles ButtonMedium.Click
        chosenOptionTwo = "Medium"
        MessageBox.Show("You have turned on the fan for " + chosenOption + " at medium setting")
        lblDescription.Text = "Currently Picked: " + chosenOption + " and " + chosenOptionTwo
    End Sub

    Private Sub ButtonLow_Click(sender As Object, e As EventArgs) Handles ButtonLow.Click
        chosenOptionTwo = "Low"
        MessageBox.Show("You have turned on the fan for " + chosenOption + " at low setting")
        lblDescription.Text = "Currently Picked: " + chosenOption + " and " + chosenOptionTwo
    End Sub

    Private Sub ButtonNoFan_Click(sender As Object, e As EventArgs) Handles ButtonNoFan.Click
        chosenOptionTwo = "No Fan"
        MessageBox.Show("You have turned off the fan in " + chosenOption)
        lblDescription.Text = "Currently Picked: " + chosenOption + " and " + chosenOptionTwo
    End Sub
End Class
