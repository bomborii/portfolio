﻿Imports System.Runtime.CompilerServices

Public Class CallContactList
    Dim PreviousCommunicationsFormReference As CommunicationsForm
    Private Sub btnCallAmara_Click(sender As Object, e As EventArgs) Handles btnCallAmara.Click, btnCallMiranda.Click
        PreviousCommunicationsFormReference = Me.FindForm
        PreviousCommunicationsFormReference.showCorrectScreen("Call Screen")


    End Sub

    Private Sub btnCallRay_Click(sender As Object, e As EventArgs) Handles btnCallRay.Click, btnCallMax.Click
        PreviousCommunicationsFormReference = Me.FindForm
        PreviousCommunicationsFormReference.showCorrectScreen("Call Screen Male")
    End Sub
End Class
