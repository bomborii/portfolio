﻿Public Class OpenWindows

    Dim chosenOption = "Entire Apartment"
    Dim chosenOptionTwo = "All Windows"
    Dim state = "will be fully closed"

    Private Sub FullyOpen_Click(sender As Object, e As EventArgs) Handles FullyOpen.Click
        state = " will be fully open."
        MessageBox.Show("The " + chosenOption + "'s " + chosenOptionTwo + " " + state)
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " " + state
    End Sub

    Private Sub ButtonHalfOpen_Click(sender As Object, e As EventArgs) Handles ButtonHalfOpen.Click
        state = " will be half open."
        MessageBox.Show("The " + chosenOption + "'s " + chosenOptionTwo + " " + state)
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " " + state
    End Sub

    Private Sub ButtonSlightlyOpen_Click(sender As Object, e As EventArgs) Handles ButtonSlightlyOpen.Click
        state = " will be slightly open."
        MessageBox.Show("The " + chosenOption + "'s " + chosenOptionTwo + " " + state)
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " " + state
    End Sub

    Private Sub ButtonFullyClosed_Click(sender As Object, e As EventArgs) Handles ButtonFullyClosed.Click
        state = " will be fully closed."
        MessageBox.Show("The " + chosenOption + "'s " + chosenOptionTwo + " " + state)
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " " + state
    End Sub

    Private Sub RoomChoice_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RoomChoice.SelectedIndexChanged
        chosenOption = RoomChoice.SelectedItem.ToString()
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " " + state
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " " + state
    End Sub

    Private Sub WindowChoice_SelectedIndexChanged(sender As Object, e As EventArgs) Handles WindowChoice.SelectedIndexChanged
        chosenOptionTwo = WindowChoice.SelectedItem.ToString()
        lblStatus.Text = "The " + chosenOption + "'s " + chosenOptionTwo + " " + state
    End Sub
End Class
