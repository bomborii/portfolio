﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MusicForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnExitMusic = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnPrev = New System.Windows.Forms.Button()
        Me.btnShuffle = New System.Windows.Forms.Button()
        Me.picVolUp = New System.Windows.Forms.PictureBox()
        Me.picVolDown = New System.Windows.Forms.PictureBox()
        Me.lblVolumePrompt = New System.Windows.Forms.Label()
        Me.lblVolume = New System.Windows.Forms.Label()
        Me.btnPause = New System.Windows.Forms.Button()
        Me.btnPlay = New System.Windows.Forms.Button()
        Me.lblCurrentSong = New System.Windows.Forms.Label()
        Me.picPlay = New System.Windows.Forms.PictureBox()
        Me.picPause = New System.Windows.Forms.PictureBox()
        Me.tmrMusicScanner = New System.Windows.Forms.Timer(Me.components)
        CType(Me.picVolUp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picVolDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPlay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPause, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnExitMusic
        '
        Me.btnExitMusic.Location = New System.Drawing.Point(274, 22)
        Me.btnExitMusic.Name = "btnExitMusic"
        Me.btnExitMusic.Size = New System.Drawing.Size(187, 23)
        Me.btnExitMusic.TabIndex = 6
        Me.btnExitMusic.Text = "Exit Music System"
        Me.btnExitMusic.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Enabled = False
        Me.btnNext.Location = New System.Drawing.Point(159, 283)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(85, 23)
        Me.btnNext.TabIndex = 5
        Me.btnNext.Text = "Next song"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnPrev
        '
        Me.btnPrev.Enabled = False
        Me.btnPrev.Location = New System.Drawing.Point(51, 283)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(90, 23)
        Me.btnPrev.TabIndex = 4
        Me.btnPrev.Text = "Previous song"
        Me.btnPrev.UseVisualStyleBackColor = True
        '
        'btnShuffle
        '
        Me.btnShuffle.Enabled = False
        Me.btnShuffle.Location = New System.Drawing.Point(51, 188)
        Me.btnShuffle.Name = "btnShuffle"
        Me.btnShuffle.Size = New System.Drawing.Size(193, 23)
        Me.btnShuffle.TabIndex = 3
        Me.btnShuffle.Text = "Shuffle playlist"
        Me.btnShuffle.UseVisualStyleBackColor = True
        '
        'picVolUp
        '
        Me.picVolUp.Image = Global.ProjectOne.My.Resources.Resource1.plus
        Me.picVolUp.Location = New System.Drawing.Point(12, 40)
        Me.picVolUp.Name = "picVolUp"
        Me.picVolUp.Size = New System.Drawing.Size(61, 54)
        Me.picVolUp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picVolUp.TabIndex = 2
        Me.picVolUp.TabStop = False
        '
        'picVolDown
        '
        Me.picVolDown.Image = Global.ProjectOne.My.Resources.Resource1.minus
        Me.picVolDown.Location = New System.Drawing.Point(99, 40)
        Me.picVolDown.Name = "picVolDown"
        Me.picVolDown.Size = New System.Drawing.Size(56, 54)
        Me.picVolDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picVolDown.TabIndex = 1
        Me.picVolDown.TabStop = False
        '
        'lblVolumePrompt
        '
        Me.lblVolumePrompt.AutoSize = True
        Me.lblVolumePrompt.Location = New System.Drawing.Point(12, 9)
        Me.lblVolumePrompt.Name = "lblVolumePrompt"
        Me.lblVolumePrompt.Size = New System.Drawing.Size(50, 15)
        Me.lblVolumePrompt.TabIndex = 0
        Me.lblVolumePrompt.Text = "Volume:"
        '
        'lblVolume
        '
        Me.lblVolume.AutoSize = True
        Me.lblVolume.Location = New System.Drawing.Point(68, 9)
        Me.lblVolume.Name = "lblVolume"
        Me.lblVolume.Size = New System.Drawing.Size(0, 15)
        Me.lblVolume.TabIndex = 7
        '
        'btnPause
        '
        Me.btnPause.Enabled = False
        Me.btnPause.Location = New System.Drawing.Point(51, 240)
        Me.btnPause.Name = "btnPause"
        Me.btnPause.Size = New System.Drawing.Size(90, 23)
        Me.btnPause.TabIndex = 8
        Me.btnPause.Text = "Pause"
        Me.btnPause.UseVisualStyleBackColor = True
        '
        'btnPlay
        '
        Me.btnPlay.Enabled = False
        Me.btnPlay.Location = New System.Drawing.Point(159, 240)
        Me.btnPlay.Name = "btnPlay"
        Me.btnPlay.Size = New System.Drawing.Size(85, 23)
        Me.btnPlay.TabIndex = 9
        Me.btnPlay.Text = "Play"
        Me.btnPlay.UseVisualStyleBackColor = True
        '
        'lblCurrentSong
        '
        Me.lblCurrentSong.AutoSize = True
        Me.lblCurrentSong.Location = New System.Drawing.Point(284, 192)
        Me.lblCurrentSong.Name = "lblCurrentSong"
        Me.lblCurrentSong.Size = New System.Drawing.Size(0, 15)
        Me.lblCurrentSong.TabIndex = 10
        '
        'picPlay
        '
        Me.picPlay.Image = Global.ProjectOne.My.Resources.Resource1.play
        Me.picPlay.Location = New System.Drawing.Point(274, 228)
        Me.picPlay.Name = "picPlay"
        Me.picPlay.Size = New System.Drawing.Size(99, 78)
        Me.picPlay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPlay.TabIndex = 11
        Me.picPlay.TabStop = False
        Me.picPlay.Visible = False
        '
        'picPause
        '
        Me.picPause.Image = Global.ProjectOne.My.Resources.Resource1.pause
        Me.picPause.Location = New System.Drawing.Point(274, 228)
        Me.picPause.Name = "picPause"
        Me.picPause.Size = New System.Drawing.Size(99, 78)
        Me.picPause.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPause.TabIndex = 12
        Me.picPause.TabStop = False
        Me.picPause.Visible = False
        '
        'tmrMusicScanner
        '
        Me.tmrMusicScanner.Enabled = True
        Me.tmrMusicScanner.Interval = 1000
        '
        'MusicForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.picPause)
        Me.Controls.Add(Me.picPlay)
        Me.Controls.Add(Me.lblCurrentSong)
        Me.Controls.Add(Me.btnPlay)
        Me.Controls.Add(Me.btnPause)
        Me.Controls.Add(Me.lblVolume)
        Me.Controls.Add(Me.btnExitMusic)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.lblVolumePrompt)
        Me.Controls.Add(Me.btnPrev)
        Me.Controls.Add(Me.picVolUp)
        Me.Controls.Add(Me.btnShuffle)
        Me.Controls.Add(Me.picVolDown)
        Me.Name = "MusicForm"
        Me.Text = "Music"
        CType(Me.picVolUp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picVolDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPlay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPause, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnExitMusic As Button
    Friend WithEvents btnNext As Button
    Friend WithEvents btnPrev As Button
    Friend WithEvents btnShuffle As Button
    Friend WithEvents picVolUp As PictureBox
    Friend WithEvents picVolDown As PictureBox
    Friend WithEvents lblVolumePrompt As Label
    Friend WithEvents lblVolume As Label
    Friend WithEvents btnPause As Button
    Friend WithEvents btnPlay As Button
    Friend WithEvents lblCurrentSong As Label
    Friend WithEvents picPlay As PictureBox
    Friend WithEvents picPause As PictureBox
    Friend WithEvents tmrMusicScanner As Timer
End Class
