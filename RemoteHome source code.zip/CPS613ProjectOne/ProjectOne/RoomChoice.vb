﻿Public Class RoomChoice
    Dim chosenOption = "Room A Door"
    Dim chosenOptionTwo = "open"
    Private Sub PickedRoom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles PickedRoom.SelectedIndexChanged
        chosenOption = PickedRoom.SelectedItem.ToString()

        If chosenOption = "Friend's Apartment" Then
            ButtonClose.Enabled = False
            ButtonOpen.Enabled = False
            ButtonLock.Enabled = False
            ButtonUnlock.Enabled = False

            lblStatus.Text = "Ringing Friend's Doorbell"
        Else
            ButtonClose.Enabled = True
            ButtonOpen.Enabled = True
            ButtonLock.Enabled = True
            ButtonUnlock.Enabled = True

            lblStatus.Text = "Currently Picked: " + chosenOption.ToString() + " " + chosenOptionTwo.ToString()
        End If
    End Sub

    Private Sub ButtonOpen_Click(sender As Object, e As EventArgs) Handles ButtonOpen.Click
        chosenOptionTwo = "open"
        MessageBox.Show("You choose to " + chosenOptionTwo + " " + chosenOption)
        lblStatus.Text = "Currently Picked: " + chosenOption.ToString() + " " + chosenOptionTwo.ToString()
    End Sub

    Private Sub ButtonClose_Click(sender As Object, e As EventArgs) Handles ButtonClose.Click
        chosenOptionTwo = "close"
        MessageBox.Show("You choose to " + chosenOptionTwo + " " + chosenOption)
        lblStatus.Text = "Currently Picked: " + chosenOption.ToString() + " " + chosenOptionTwo.ToString()
    End Sub

    Private Sub ButtonLock_Click(sender As Object, e As EventArgs) Handles ButtonLock.Click
        chosenOptionTwo = "lock"
        MessageBox.Show("You choose to " + chosenOptionTwo + " " + chosenOption)
        lblStatus.Text = "Currently Picked: " + chosenOption.ToString() + " " + chosenOptionTwo.ToString()
    End Sub

    Private Sub ButtonUnlock_Click(sender As Object, e As EventArgs) Handles ButtonUnlock.Click
        chosenOptionTwo = "unlock"
        MessageBox.Show("You choose to " + chosenOptionTwo + " " + chosenOption)
        lblStatus.Text = "Currently Picked: " + chosenOption.ToString() + " " + chosenOptionTwo.ToString()
    End Sub
End Class
