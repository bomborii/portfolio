﻿Public Class ControlHumidity

    Dim humidity = 40
    Private Sub IncreaseHumidity_Click(sender As Object, e As EventArgs) Handles IncreaseHumidity.Click
        If humidity > 0 Then
            humidity += 1
        End If
        lblHumidity.Text = humidity.ToString() + "%"
    End Sub

    Private Sub DecreaseHumidity_Click(sender As Object, e As EventArgs) Handles DecreaseHumidity.Click
        If humidity < 100 Then
            humidity -= 1
        End If
        lblHumidity.Text = humidity.ToString() + "%"
    End Sub
End Class
