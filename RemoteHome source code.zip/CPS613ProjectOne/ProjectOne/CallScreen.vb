﻿Public Class CallScreen
    Dim PreviousCommunicationsFormReference As CommunicationsForm
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.lblMessageDisplay.Visible = False
        PreviousCommunicationsFormReference = Me.FindForm
        PreviousCommunicationsFormReference.showCorrectScreen("Call Contact List")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click, Button2.Click, Button3.Click, Button4.Click
        Me.lblMessageDisplay.Visible = True
        Me.lblMessageDisplay.Text = sender.Tag.ToString
    End Sub
End Class
