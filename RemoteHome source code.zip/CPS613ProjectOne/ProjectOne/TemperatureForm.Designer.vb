﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TemperatureForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.BackButton = New System.Windows.Forms.Button()
        Me.OpenWindows = New ProjectOne.OpenWindows()
        Me.WindowBlinds = New ProjectOne.WindowBlinds()
        Me.ControlFan = New ProjectOne.ControlFan()
        Me.ControlLights = New ProjectOne.ControlLights()
        Me.RoomChoice = New ProjectOne.RoomChoice()
        Me.TemperatureControl = New ProjectOne.TemperatureControl()
        Me.ControlHumidity = New ProjectOne.ControlHumidity()
        Me.SuspendLayout()
        '
        'BackButton
        '
        Me.BackButton.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.BackButton.Location = New System.Drawing.Point(65, 523)
        Me.BackButton.Name = "BackButton"
        Me.BackButton.Size = New System.Drawing.Size(117, 41)
        Me.BackButton.TabIndex = 0
        Me.BackButton.Text = "Back"
        Me.BackButton.UseVisualStyleBackColor = True
        '
        'OpenWindows
        '
        Me.OpenWindows.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.OpenWindows.Location = New System.Drawing.Point(264, 82)
        Me.OpenWindows.Name = "OpenWindows"
        Me.OpenWindows.Size = New System.Drawing.Size(599, 373)
        Me.OpenWindows.TabIndex = 1
        '
        'WindowBlinds
        '
        Me.WindowBlinds.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.WindowBlinds.Location = New System.Drawing.Point(231, 70)
        Me.WindowBlinds.Name = "WindowBlinds"
        Me.WindowBlinds.Size = New System.Drawing.Size(649, 415)
        Me.WindowBlinds.TabIndex = 2
        '
        'ControlFan
        '
        Me.ControlFan.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ControlFan.Location = New System.Drawing.Point(163, 41)
        Me.ControlFan.Name = "ControlFan"
        Me.ControlFan.Size = New System.Drawing.Size(747, 444)
        Me.ControlFan.TabIndex = 3
        '
        'ControlLights
        '
        Me.ControlLights.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ControlLights.Location = New System.Drawing.Point(184, 53)
        Me.ControlLights.Name = "ControlLights"
        Me.ControlLights.Size = New System.Drawing.Size(708, 432)
        Me.ControlLights.TabIndex = 4
        '
        'RoomChoice
        '
        Me.RoomChoice.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.RoomChoice.Location = New System.Drawing.Point(211, 41)
        Me.RoomChoice.Name = "RoomChoice"
        Me.RoomChoice.Size = New System.Drawing.Size(643, 485)
        Me.RoomChoice.TabIndex = 5
        '
        'TemperatureControl
        '
        Me.TemperatureControl.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.TemperatureControl.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.TemperatureControl.Location = New System.Drawing.Point(325, 125)
        Me.TemperatureControl.Name = "TemperatureControl"
        Me.TemperatureControl.Size = New System.Drawing.Size(402, 296)
        Me.TemperatureControl.TabIndex = 6
        '
        'ControlHumidity
        '
        Me.ControlHumidity.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ControlHumidity.Location = New System.Drawing.Point(347, 150)
        Me.ControlHumidity.Name = "ControlHumidity"
        Me.ControlHumidity.Size = New System.Drawing.Size(354, 305)
        Me.ControlHumidity.TabIndex = 7
        '
        'TemperatureForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1055, 602)
        Me.Controls.Add(Me.ControlHumidity)
        Me.Controls.Add(Me.TemperatureControl)
        Me.Controls.Add(Me.RoomChoice)
        Me.Controls.Add(Me.ControlLights)
        Me.Controls.Add(Me.ControlFan)
        Me.Controls.Add(Me.WindowBlinds)
        Me.Controls.Add(Me.OpenWindows)
        Me.Controls.Add(Me.BackButton)
        Me.Name = "TemperatureForm"
        Me.Text = "Environment Form"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BackButton As Button
    Friend WithEvents OpenWindows As OpenWindows
    Friend WithEvents WindowBlinds As WindowBlinds
    Friend WithEvents ControlFan As ControlFan
    Friend WithEvents ControlLights As ControlLights
    Friend WithEvents RoomChoice As RoomChoice
    Friend WithEvents TemperatureControl As TemperatureControl
    Friend WithEvents ControlHumidity As ControlHumidity
End Class
